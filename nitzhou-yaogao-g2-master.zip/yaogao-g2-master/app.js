//app.js
const util = require('/utils/util.js')
App({

  //添加一个消息提醒事件
  hasInform: function () {
    wx.request({
      url: this.globalData.address + '/api/article/hasAllRead.html',
      data: {
        // userId: this.globalData.userId,
        openid: this.globalData.openId,
      },
      success: (res) => {
        if (!res.data.hasAllRead) {
          util.showRedDot(2)

          this.globalData.hasAllRead = false
        } else {
          util.hideRedDot(2)

          this.globalData.hasAllRead = true
        }
      }
    })
  },

  onLaunch: function () {
    //  展示本地存储能力
    // var logs = wx.getStorageSync('logs') || [];
    // logs.unshift(Date.now());
    // wx.setStorageSync('logs', logs);
    var that = this;
    // 登录
    // that.userLogin();
  },

  userLogin:function(inviteCode=null){
    var that = this;
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        wx.request({
          url: that.globalData.address + '/api/user/login.html',
          data: {
            code: res.code,
            inviteCode: inviteCode,
            
          },
          success: (res) => {
            that.globalData.openId = res.data.data.openid;
            that.globalData.inviteCode = res.data.data.inviteCode;
            this.globalData.isNew = res.data.data.isNew;
            this.getUserInfo()
            if (this.openIdReadyCallback) {
              if (that.globalData.openId) {
                this.openIdReadyCallback(res)
              }
            }
          }
        })
      }
    })
  },

// // 底部导航栏
//   getTabBarhome:function(){
//     wx.request({
//       url: this.globalData.address + '/api/icon/home.html',
//       success: (res) => {
//         wx.setTabBarStyle({
//           color: res.data.data.recolor,
//           selectedColor: res.data.data.color
//         });
//         wx.setTabBarItem({
//           index: 0,
//           text:res.data.data.name,
//           iconPath: '/path/to/res.data.data.unChecked',
//           selectedIconPath: '/path/to/res.data.data.checked'
//         })
//       }
//     })
//   },

  getUserInfo: function() {
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              this.globalData.userInfo = res.userInfo
              this.setUserInfo(res.userInfo)

              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },

  globalData: {
    userInfo: null,
    // address: 'https://tooth.vverp.com',
    address: 'http://47.100.37.213:8080',
    // address: 'http://192.168.1.100:8080',
    openId: '',
    inviteCode:'',
    exhibitionId:'',
    isNew:'',
  },

  // 转发
  sharePage:function(path){
    return{
      title:"VANMAX 口腔护理",
      path:path,
      imageUrl:"https://vverp1.oss-cn-shanghai.aliyuncs.com//uploadFile/c46e3140-98cb-4306-91a3-99884650c424.png",
      success:(res)=>{
        wx.request({
          url: this.globalData.address +'/api/pointLog/share.html',
          data:{
            openid:this.globalData.openId,
          },
          success:(res)=>{
            wx.showModal({
              title: '分享成功',
              content: '获得¥'+res.data.data,
              showCancel:false,
              success:function(res){
                // console.log(res);
              },
              fail:function(){
                // console.log('fail');
              }
            })
          }
        })
      }
    }
  },

  setUserInfo: function (userInfo) {
    wx.request({
      url: this.globalData.address + '/api/wechat/setUserInfo.html',
      data: {
        userInfo: userInfo,
        openid: this.globalData.openId,
      }
    })
  },

 
})