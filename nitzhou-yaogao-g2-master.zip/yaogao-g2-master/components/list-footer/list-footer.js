// components/list-footer/list-footer.js
Component({
  properties: {
    type: {
      type: String,
      value: "text"
    },
    title: {
      type: String,
      value: "已加载全部"
    }
  },
  data: {

  },
  methods: {

  }
})
