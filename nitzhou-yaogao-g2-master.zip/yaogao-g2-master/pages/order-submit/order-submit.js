// order-submit.js  
const app = getApp();
const payment = require('../../utils/payment.js');
const regex = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paymentPop: false,
    editNum: false,
    payIndex: 0,
    courierIndex: 0,
    payments: ["微信支付", "余额支付"],
    Courier: {},
    exhibition: false,
    inputIdCard: '',
    saveBtn: false,
    edit: false,
    isinvoice: false,
    invoiceId: '',
    invoiceText: false,
    idCard: '',
    isIdCard: false,
    isCheckIdCard: false,
    checked: '',
    subPrice: "",
    coupon: '',
    couponName: "优惠券",
    allQuantity: "",
    couponsize: 0,
    use: false,
    orderPrice: '',
    total_price: 0,
    address: null,
    express_price: -1,
    content: '',
    offline: 0,
    // express_price_1: 0.00,
    name: "",
    mobile: "",
    addressId: '',
    productId: '',
    quantity: '',
    tax: 0.00 //开发票的税金
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var page = this;
    if (app.globalData.exhibitionId > 1) {
      page.setData({
        exhibition: true,
      })
    } else {
      page.setData({
        exhibition: false,
      })
    }
    if (options.goods_info)
    {
      var goods_info = JSON.parse(options.goods_info);
      page.setData({
        goods_info:goods_info,
      })
    }
    if (options.goods_info || options.cart_id_list) {
      page.setData({
        use: true,
      })
    }
    page.setData({
      options: options,
      store: wx.getStorageSync("store")
    });

    page.getOrderData(options);
    page.getCourierList();
  },

  bindkeyinput: function(e) {
    this.setData({
      content: e.detail.value
    });
  },
  KeyName: function(e) {
    this.setData({
      name: e.detail.value
    });
  },
  KeyMobile: function(e) {
    this.setData({
      mobile: e.detail.value
    });
  },

  // getOffline: function (e) {
  //   var express = this.data.express_price;
  //   var express_1 = this.data.express_price_1;
  //   var offline = e.target.dataset.index;
  //   if (offline == 1) {
  //     this.setData({
  //       offline: offline,
  //       express_price: 0,
  //       express_price_1: express
  //     });
  //   } else {
  //     this.setData({
  //       offline: offline,
  //       express_price: express_1
  //     });
  //   }
  // },


  // 去支付
  orderSubmit: function() {
    var page = this;
    var payIndex = page.data.payIndex;
    if (!page.data.use) {
      return;
    }
    var offline = page.data.offline;

    if (offline == 0) {
      if (page.data.address == '' || page.data.addressId == '') {
        if (page.data.exhibition) {
          wx.showToast({
            title: "请选择收货人信息",
            image: "/img/icon-warning.png",
          });
        } else {
          wx.showToast({
            title: "请选择收货地址",
            image: "/img/icon-warning.png",
          });
        }

        return;
      }
   
      wx.showLoading({
        title: "正在提交",
        mask: true,
      });
        page.submitorder();
    }
  },


  //提交商品详情订单
  goodsDetailSubmit:function(page){
    var index = page.data.courierIndex;
    var data={};
    data.paymentMethodId = page.data.payIndex == 0 ? 1 : 4;
    data.deliveryCorpName = page.data.Courier.shippingMethods[page.data.courierIndex];
    data.idCard = page.data.idCard,
      data.receiverId = page.data.addressId;
    data.productId = page.data.productId;
    data.quantity = page.data.quantity;
    data.openid = app.globalData.openId;
    data.invoiceId = page.data.invoiceId
    data.exhibitionId = app.globalData.exhibitionId;
    data.shippingMethodId = page.data.Courier.isShippingChose? page.data.Courier.shippingMethods[index].id:1;
    if (page.data.content) {
      data.memo = page.data.content
    }
    if (page.data.coupon) {

      data.code = page.data.coupon.code;
    } else {
      data.code = null;
    }
    wx.request({
      url: app.globalData.address + '/api/order/create2.html',
      data: data,
      success: function (res) {
        if (res.data.code == 0) {
          page.setData({
            use: false,
            paymentPop: false,
          })

          setTimeout(function () {
            wx.hideLoading();
          }, 1000);

          // 支付接口
          page.orderPay(page, res);

        }

        if (res.data.code == 1) {
          wx.hideLoading();
          wx.showToast({
            title: res.data.msg,
            image: "/img/icon-warning.png",
          });
          return;
        }
      },
      complete: function () {
        // console.log(3);
      },
    });
  },

  // 提交订单
  submitorder:function(){
    var page = this;
    if (page.data.options.cart_id_list) {

      // 提交购物车订单
      page.submitCarOrder(page);

    } else if (page.data.options.goods_info) {
      if (!page.data.productId) {
        wx.showToast({
          title: '商品该规格已下架，无法购买',
          icon: 'none',
          mask: true,
          duration: 1000,
        })
        return;
      }

      //提交商详情订单
      page.goodsDetailSubmit(page)
    }
    else {
      console.log(4);
    }
  },


  // 获取订单数据渲染到页面
  getOrderData: function(options,callBack=null) {
    var page = this;
    var address_id = "";
    if (page.data.address && page.data.address.id)
      address_id = page.data.address.id;
    //从购物车进入结算
    if (options.cart_id_list) {
      var cart_id_list = JSON.parse(options.cart_id_list);
      wx.showLoading({
        title: "正在加载",
        mask: true,
      });
      page.carOrder(page,callBack);

    }
    //从商品详情进入结算
    if (options.goods_info) {
      //string转json
      var goods_info = page.data.goods_info;
      page.setData({
        productId: goods_info.goods_id,
        quantity: goods_info.num,
      })
      var that = this

      wx.showLoading({
        title: "正在加载",
        mask: true,
      });
      var index = that.data.courierIndex;
      // console.log(that.data.Courier)
      wx.request({
        url: app.globalData.address + "/api/order/checkout2.html",
        data: {
          receiverId: page.data.addressId,
          code: page.data.coupon ? page.data.coupon.code : null,
          invoiceId:page.data.invoiceId,
          productId: goods_info.goods_id,
          exhibitionId: app.globalData.exhibitionId,
          quantity: goods_info.num,
          openid: app.globalData.openId,
          shippingMethodId: Object.keys(that.data.Courier) == 0 ? 1 : that.data.Courier.shippingMethods[index].id,
        },
        success: function(res) {
          wx.hideLoading();

          if (res.data.code == 0) {
            page.setData({
              quantity: res.data.data.order.orderItems[0].quantity,
              idCard: res.data.data.idCard,
              isIdCard: res.data.data.isIdCard,
              isinvoice: res.data.data.isinvoice,
              tax: res.data.data.tax,
              orderPrice: res.data.data.order.price,
              couponsize: res.data.data.couponsize,
              total_price: res.data.data.order.amount,
              beforePrice: res.data.data.order.amount,
              goods_list: res.data.data.order.orderItems,
              address: res.data.data.order.areaName + res.data.data.order.address,

              express_price: res.data.data.order.freight,

              name: res.data.data.order.address ? res.data.data.order.consignee : '',
              mobile: res.data.data.order.address ? res.data.data.order.phone : '',
              addressId: res.data.data.defaultReceiverId,
              allQuantity: that.getAllQuantity(res.data.data.order.orderItems)
              //send_type: res.data.send_type,
            },()=>{
              if(callBack)
              {
                callBack();
              }
            });
            if (res.data.send_type == 1) { //仅快递
              page.setData({
                offline: 0,
              });
            }
            if (res.data.send_type == 2) { //仅自提
              page.setData({
                offline: 1,
              });
            }
          }
          if (res.data.code == 1) {
            wx.showModal({
              title: "提示",
              content: res.msg,
              showCancel: false,
              confirmText: "返回",
              success: function(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1,
                  });
                }
              }
            });
          }
        }
      });
    }
  },

  // 得到allQuantity数据
  getAllQuantity: function(orderItems) {
    var allQuantity = 0;
    for (var i = 0; i < orderItems.length; i++) {
      allQuantity = allQuantity + orderItems[i].quantity;
    }
    return allQuantity;
  },

  copyText: function(e) {
    var text = e.currentTarget.dataset.text;
    if (!text)
      return;
    wx.setClipboardData({
      data: text,
      success: function() {
        wx.showToast({
          title: "已复制内容",
        });
      },
      fail: function() {
        wx.showToast({
          title: "复制失败",
          image: "/images/icon-warning.png",
        });
      },
    });
  },

  // showCouponPicker: function () {
  //   var page = this;
  //   if (page.data.coupon_list && page.data.coupon_list.length > 0) {
  //     page.setData({
  //       show_coupon_picker: true,
  //     });
  //   }
  // },



  // 取消支付后跳转到订单页面
  cancelToOrder: function() {
    wx.redirectTo({
      url: '/pages/order/order?currentTab=' + 0,
    })
  },

  // 从后台购物车中获取订单
  carOrder: function(page,callBack=null) {
    var that = page;
    var index = that.data.courierIndex;
    // console.log(that.data.Courier)
    wx.request({
      url: app.globalData.address + '/api/order/checkout.html',
      data: {
        receiverId: page.data.addressId,
        invoiceId: that.data.invoiceId,
        openid: app.globalData.openId,
        exhibitionId: app.globalData.exhibitionId,
        shippingMethodId: Object.keys(that.data.Courier)==0?1:that.data.Courier.shippingMethods[index].id,
        code: that.data.coupon ? that.data.coupon.code : null,
      },
      success: function(res) {
        if (res.data) {
          wx.hideLoading();
          if (res.data.code === 0) {
            page.setData({
              quantity: res.data.data.order.orderItems[0].quantity,
              tax: res.data.data.tax,
              idCard: res.data.data.idCard,
              isIdCard: res.data.data.isIdCard,
              isinvoice: res.data.data.isinvoice,
              couponsize: res.data.data.couponsize,
              express_price: res.data.data.order.freight,
              orderPrice: res.data.data.order.price,
              total_price: res.data.data.order.amount,
              beforePrice: res.data.data.order.amount,
              goods_list: res.data.data.order.orderItems,
              address: res.data.data.order.areaName + res.data.data.order.address,
              name: res.data.data.order.address ? res.data.data.order.consignee : '',
              mobile: res.data.data.order.address ? res.data.data.order.phone : '',
              addressId: res.data.data.defaultReceiverId,
              allQuantity: that.getAllQuantity(res.data.data.order.orderItems)

            },()=>{
              if (callBack) {
                callBack();
              }
            });

            if (res.data.send_type == 1) { //仅快递
              page.setData({
                offline: 0,
              });
            };
            if (res.data.send_type == 2) { //仅自提
              page.setData({
                offline: 1,
              });
            };
          }
          if (res.data.code === 1) {
            wx.showModal({
              title: "提示",
              content: res.msg,
              showCancel: false,
              confirmText: "返回",
              success: function(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1,
                  });
                }
              }
            });
          }

        }

      },
    })
  },

  // 提交购物车订单
  submitCarOrder: function(page) {
    var index = page.data.courierIndex;
    wx.request({
      url: app.globalData.address + '/api/order/create.html',
      data: {
        paymentMethodId: page.data.payIndex == 0 ? 1 : 4,
        deliveryCorpName: page.data.Courier.shippingMethods[page.data.courierIndex],
        openid: app.globalData.openId,
        receiverId: page.data.addressId,
        code: page.data.coupon ? page.data.coupon.code : null,
        invoiceTitle: "123456",
        balance: 0,
        idCard: page.data.idCard,
        invoiceId: page.data.invoiceId,
        memo: page.data.content ? page.data.content : null,
        exhibitionId: app.globalData.exhibitionId,
        shippingMethodId: page.data.Courier.isShippingChose ? page.data.Courier.shippingMethods[index].id : 1,
      },
      success: function(res) {
        if (res.data) {
          setTimeout(function() {
            wx.hideLoading();
          }, 1000);
        

          if (res.data.code === 0) {
            page.setData({
              use: false,
              paymentPop: false,
            })

            // 支付接口
            page.orderPay(page, res);

          } else {
            wx: wx.showToast({
              title: res.data.msg,
              image: "/img/icon-warning.png",
              duration: 1000,
              mask: true,
            })
          }
        }
      }
    })
  },

  // 支付接口
  orderPay: function(page, res) {
    let data = res.data.data;
    wx.hideLoading()
    if (data.method === "wx") {
      payment.initPay(data.wx, () => {
        wx.redirectTo({
          url: `/pages/pay-success/pay-success?price=${page.data.total_price}&&id=${res.data.data.orderId}`
        })
      }, (res) => {
        if (res.errMsg === "requestPayment:fail cancel") {
          wx.showToast({
            title: '支付被取消',
            icon: 'none',
            duration: 650,
          });
          setTimeout(() => {
            page.cancelToOrder();
          }, 500)
        } else {
          wx.showToast({
            title: '支付失败',
            icon: 'none',
            duration: 650,
          });
          setTimeout(() => {
            page.cancelToOrder();
          }, 500)
        }
      })
    }
    else if (data.method === "balance") {
      if(data.result)
      {
        page.setData({
          paymentPop: true,
          sn: data.sn
        })
      }
      else{
        wx.showToast({
          title: data.reason,
          icon: 'none',
          duration: 1500,
          success:function(){
            page.setData({
              use:true,
            })
          }
        });
      }
    }
  },
  // 支付失败
  payError:function(){
    var page = this;
    wx.showToast({
      title: "支付失败",
      icon: 'none',
      duration: 1500,
    });
    setTimeout(() => {
      page.cancelToOrder();
    }, 1000);
  },

  // 确认支付
  confirmtoPay:function(){
    var page = this;
    wx.request({
      url: app.globalData.address + '/api/order/create3.html',
      data: {
        openid: app.globalData.openId,
        sn: page.data.sn,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function (res) {
        
        if (res.data.data.result == 'success')
        {
          
          wx.redirectTo({
            url: `/pages/pay-success/pay-success?price=${page.data.total_price}&&id=${res.data.data.orderId}`
          })
        }
        else{
          // console.log(res.data.data.result);
        }
        
      }

    })
  },

  //  选择优惠卷
  selectCoupon: function() {
    if (this.data.couponsize == 0) {
      return;
    }
    wx.navigateTo({
      url: "/pages/choose-coupon/choose-coupon?params=" + JSON.stringify({
        price: this.data.orderPrice,
        allQuantity: this.data.allQuantity,
        code: this.data.coupon ? this.data.coupon.code : null
      }),

    })
  },

  //  发票的跳转
  goToInvoice: function() {
    var that = this;
    wx.navigateTo({
      url: '/pages/invoice/invoice?params=' + JSON.stringify({
        name: that.data.name,
        phone: that.data.mobile,
        money: that.data.total_price,
      }),
    })
  },

  chexckidCard: function(value) {
    var that = this;
    var idCard = value;
    if (!regex.test(idCard)) {
      that.setData({
        isCheckIdCard: false,
        idCard: '',
      }, () => {
        wx: wx.showToast({
          title: '请输入正确的身份证号码',
          icon: 'none',
          duration: 1200,
          mask: true,
        })
      })
      return;
    } else {
      that.setData({
        isCheckIdCard: true,
        idCard: idCard,
      })
      wx.request({
        url: app.globalData.address + '/api/user/idCard.html ',
        data: {
          openid: app.globalData.openId,
          idcard: idCard,
        },
        success: function(res) {
          if (res.data.code == 0) {
            that.setData({
              idCard: idCard,
              edit: false,
            })
          } else {
            that.setData({
              edit: true,
              idCard: '',
            }, () => {
              wx.showToast({
                title: '保存失败',
                icon: 'none',
                duration: 1200,
                mask: true,
              })
            })
          }
        }
      })
    }
  },

  changeEdit: function() {
    this.setData({
      edit: true,
      idCard: '',
      inputIdCard: '',
      saveBtn: false,
    })
  },

  changeBtn: function(e) {
    var value = e.detail.value;
    if (value) {
      this.setData({
        saveBtn: true,
        inputIdCard: value,
      })
    }
  },

  saveIdCard: function() {
    const that = this;
    if (!that.data.saveBtn) {
      return;
    }
    that.chexckidCard(that.data.inputIdCard);
  },

  bindchangeIndex: function(e) {
    var index = e.detail.value;
    // console.log(e);
    var name = e.currentTarget.dataset.name;
    if (name === "courierIndex") {
      this.setData({
        courierIndex: index,
      },()=>{
        this.getOrderData(this.data.options)
      });
    } else if (name === "payIndex") {
      this.setData({
        payIndex: index,
      })
    } else {
      console.log("Error");
    }
  },

  //修改数量
  changeQuantity: function(e) {
    var page=this;
    var goods_list = this.data.goods_list;
    var total_price = this.data.express_price;
    var simpelPrice = goods_list[0].price;
    var quantity = e.detail.quantity;
    if (this.data.options.cart_id_list) {
      this.editNumRequest(goods_list[0].id,quantity);
    }
    goods_list[0].quantity = quantity;
    total_price = total_price + (quantity * simpelPrice)
    // console.log(page)
    this.setData({
      // total_price: total_price,
      quantity: quantity,
      goods_list: goods_list,
      "goods_info.num":quantity,
    },()=>{
      if (page.options.goods_info)
      {
        // console.log(1);
        page.getOrderData(page.options);
      }
    })

    if (e.detail.hidden) {
      if (!e.detail.hidden) {
        this.isEditNum();
      }
    } else {
      this.isEditNum();
    }
  },

  noticelongtap: function() {
    return
  },

  isEditNum: function() {
    this.setData({
      editNum: !this.data.editNum,
    })
  },

  editNumRequest: function(id, quantity) {
    var page = this;
    wx.request({
      url: app.globalData.address + '/api/cart/update.html',
      data: {
        id: id,
        openid: app.globalData.openId,
        quantity: quantity
      },
      success: function(res) {
        if(res.data.code==0)
        {
          page.getOrderData(page.options);
        }
        else{
          wx.showToast({
            title: res.data.msg,
            icon:'none',
            duration: 1000,
          })
        }
      }
    })
  },
  getCourierList: function() {
    wx.request({
      url: app.globalData.address + '/api/shipping/list.html',
      data: {
        openid: app.globalData.openId,
      },
      success: (res) => {
        if (res.data.code == 0) {
          this.setData({
            Courier: res.data.data,
          })
        }
      }
    })
  }
});