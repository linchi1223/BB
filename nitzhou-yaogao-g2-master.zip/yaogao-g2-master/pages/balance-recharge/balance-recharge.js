// pages/balance-recharge/balance-recharge.js

const app = getApp()
const payment = require('../../utils/payment.js')

Page({
  data: {

  },
  onLoad: function (options) {

  },
  numChange: function (e) {
    const amount = parseFloat(e.detail.value)

    this.setData({
      amount
    })
  },

  clickBtn: function () {
    const amount = this.data.amount

    if (!amount) {
      wx.showToast({
        title: '请输入金额',
        icon:"none",
        duration:1000,
      })
      return
    }

    wx.request({
      url: app.globalData.address +"/api/wxPay/chongZhi.html",      
      data:{
        openid:app.globalData.openId,
        amount
      },
      success: (res) => {
        if (res.data) {
          const data = res.data

          payment.initPay(data, () => {
            const pages = getCurrentPages()
            const beforePage = pages[pages.length - 2]

            if (beforePage.__route__ === 'pages/wallet/wallet') {
              wx.navigateBack({
                success: () => {
                  beforePage.getMoney();
                }
              })
            } else {
              wx.navigateBack({})
            }
          }, () => {
            wx.showToast({
              title: '支付失败',
              icon: 'none'
            })
          })
        }
      }
    })
  }
})