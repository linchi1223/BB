// pages/information/information.js

const app = getApp()
const util = require('../../utils/util.js')
const pageable = require('../../utils/pageable.js')

Page({
  data: {
    pageNumber: 0,
    pageSize: 10
  },
  onShow: function () {
    this.setData({
      pageNumber: 0
    }, this.getPageItem)
    app.hasInform()
  },
  onReachBottom: function () {
    this.getPageItem()
  },

  getPageItem: function () {
    const url = `${app.globalData.address}/api/article/list.html`;
    let params = {
      // userId: app.globalData.userId,
      openid: app.globalData.openId,
    };

    pageable.getPage(this, url, params, 'data', () => { }, true)
  },
  goToinforDeli: function (e) {
    const id = e.currentTarget.dataset.id
    const hasRead = e.currentTarget.dataset.hasRead
    const index = e.currentTarget.dataset.index

    wx.navigateTo({
      url: `/pages/inforDeli/inforDeli?id=${id}&hasRead=${hasRead}&index=${index}`
    });
  }
})