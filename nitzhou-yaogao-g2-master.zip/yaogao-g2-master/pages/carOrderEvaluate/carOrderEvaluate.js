
const app = getApp();
Page({
  data:{
    order:{},
    refund:false,
    eva:false,
    refunded:false,
    evaed:false,
    sn:'',
  },
onLoad:function(options)
  {
    var params = JSON.parse(options.params);
    this.getOrder(params.sn);
  if (params.frm && params.frm=='refund')
    {
      this.setData({
        refund:true,
        sn:params.sn,
      })
    }
  if (params.frm && params.frm == 'eva') {
    this.setData({
      eva: true,
      sn: params.sn,
    })
  }
  },

  getOrder:function(sn){
    const that  =this;
    wx.request({
      url: app.globalData.address +'/api/order/view.html',
      data:{
        sn:sn,
        openid:app.globalData.openId,
      },
      success:function(res){
        if(res.data)
        {
          if(res.data.code == 0)
          {
            that.setData({
              order: res.data.data,
            })
          }
        }
      }
    })
  },

  evaluate:function(e){
    var index = e.currentTarget.dataset.index;
    var orderItems = this.data.order.orderItems;
    if (orderItems)
    {
      wx.navigateTo({
        url: '/pages/myevaluate/myevaluate?params=' + JSON.stringify({
          orderItemId: orderItems[index].id,
          productId: orderItems[index].productId,
          imgSrc: orderItems[index].thumbnail,
          name: orderItems[index].name,
          index:index,
        }),
      })
    }
  },

  // 退款
  refund:function(e){
    var index = e.currentTarget.dataset.index;
    var orderItems = this.data.order.orderItems;
    const that = this;
    that.refundRequset(orderItems[index].id,that)
  },

  refundRequset: function (id, that) {
    wx.request({
      url: app.globalData.address + '/api/order/return.html',
      data: {
        orderItemId: id,
        openid: app.globalData.openId,
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.showToast({
            title: '申请退款成功',
            icon: 'success',
            mask: true,
            duration: 1500,
          })
          setTimeout(()=>{
            that.getOrder(that.data.sn)
          },600)
        }
      }
    })
  },
})