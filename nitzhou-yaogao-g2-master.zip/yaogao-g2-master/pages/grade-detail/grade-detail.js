// pages/grade-detail/grade-detail.js

const app = getApp()
const pageable = require("../../utils/pageable.js")

Page({
  data: {
    pageNumber: 0,
    pageSize: 10
  },
  onLoad: function (options) {
    if (options.grade) {
      this.setData({
        grade: options.grade
      })
    }

    this.getPageItem()
  },
  onReachBottom: function() {
    this.getPageItem()
  },
  getPageItem: function() {
    const url = `${app.globalData.address}/api/pointLog/list.html`
    const params = {
      openId: app.globalData.openId
    }

    pageable.getPage(this, url, params, 'content')
  }
})