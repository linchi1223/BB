const app = getApp();
const WxParse = require("../../wxParse/wxParse.js")
Page({
  data:{
    amount:0,
    canUseAmount:0,
    usedAmount:0,
    pendingAmount:0,
    introductionContent:false,
    notice:'',
  },
  onLoad:function(options){
    this.getMoney(this);
    this.getNotice();
  },
  getMoney:function(that){
    wx.request({
      url: app.globalData.address + '/api/distributionBrokerage/amount.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        if(res.data.code==0){
          that.setData({
            amount: res.data.data.amount,
            canUseAmount: res.data.data.canUseAmount,
            usedAmount: res.data.data.usedAmount,
            pendingAmount: res.data.data.pendingAmount,

          })
        }
      }
    })
  },
  goToWithdrawcash:function(){
    var that = this;
    wx.navigateTo({
      url: '/pages/withdrawCash/withdrawCash?canUseAmount='+that.data.canUseAmount,
    })
  },
  showContent:function(){
    this.setData({
      introductionContent: !this.data.introductionContent,
    })
  },
  getNotice:function(){
    var that = this;
    wx.request({
      url: app.globalData.address+'/api/article/distributuionNotice.html',
      data:{
        openid:app.globalData.openId,
      },
      success:(res)=>{
        if(res.data.code==0){
          var content = res.data.data.content;
          if(content){
            WxParse.wxParse('detail','html',content,that);
          }
        }
      }
    })
  },
  deatilTap:function(){
    wx.navigateTo({
      url: '/pages/distribution-detail/distribution-detail?currentTab=0',
    })
  }
})