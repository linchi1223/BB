// pages/withdrawCash/withdrawCash.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0, 
    userName:'',
    name:'',
    accountNumber:'',
    money:'',
    withdrawCash:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // console.log(options)
    that.setData({
      canUseAmount: options.canUseAmount,
    });
    that.setData({
      canUseAmount: options.canUseAmount,
    })
    // this.withdrawCash();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  //点击切换
  clickTab: function (e) {
    if (e === null) {
      return;
    }
    var that = this;
    if (this.data.currentTab === e.currentTarget.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.currentTarget.dataset.current
      })
    }
  },
  //滑动切换
  swiperTab: function (e) {
    var that = this;
    var params = null

    var currentTab = e.detail.current ? e.detail.current : 0;
    that.setData({
      currentTab: e.detail.current,
    }, () => {
      
    });

  },
  // 提现方式(微信)
  weiTap:function(){
    let userName = this.data.userName;
    if (!userName || userName.length <= 0) {
      wx.showToast({
        title: '请输入正确的姓名',
        icon: "none"
      })
      return;

    };
    let accountNumber = this.data.accountNumber;
    if (!accountNumber || accountNumber.length <= 0) {
      wx.showToast({
        title: '请输入正确的微信账号',
        icon: "none"
      })
      return;
    };
    let money = this.data.money;
    money=parseFloat(money);
    typeof(money);
    const canUseAmount = this.data.canUseAmount || '';
    if (!money || money <1 || money >= canUseAmount) {
      wx.showToast({
        title: '请输入规定提现金额',
        icon: "none"
      })
      return;
    };
      var that = this;
      if (this.data.currentTab == 0) {
        this.data.currentTab = '微信'
      } else if (this.data.currentTab == 1) {
        this.data.currentTab = '支付宝'
      } else if (this.data.currentTab == 2) {
        this.data.currentTab = '银行卡'
      } else if (this.data.currentTab == 3) {
        this.data.currentTab = '余额'
      }
      wx.request({
        url: app.globalData.address + "/api/distributionBrokerage/withdraw.html",
        data: {
          openid: app.globalData.openId,
          amount: this.data.money,
          method: this.data.currentTab,
          bank: this.data.name,
          account: this.data.accountNumber,
          name: this.data.userName,
        },
        success: function (res) {
          that.setData({
            withdrawCash: res.data.data
          })
        }
      })

    wx.navigateTo({
      url: '/pages/distribution-center/distribution-center'
    })
  },
  nameTap:function(e){
    this.setData({
      userName: e.detail.value
    })
  },
  numberTap:function(e){
    this.setData({
      accountNumber: e.detail.value
    })
  },
  // 提现方式(支付宝)
  zhiTap:function(){
    let userName = this.data.userName;
    if (!userName || userName.length <= 0) {
      wx.showToast({
        title: '请输入正确的姓名',
        icon: "none"
      })
      return;

    };
    let accountNumber = this.data.accountNumber;
    if (!accountNumber || accountNumber.length <= 0) {
      wx.showToast({
        title: '请输入正确的支付宝账号',
        icon: "none"
      })
      return;
    };
    let money = this.data.money;
    money = parseFloat(money);
    typeof (money);
    const canUseAmount = this.data.canUseAmount || '';
    if (!money || money < 1 || money >= canUseAmount) {
      wx.showToast({
        title: '请输入规定提现金额',
        icon: "none"
      })
      return;
    };

    var that = this;
    if (this.data.currentTab == 0) {
      this.data.currentTab = '微信'
    } else if (this.data.currentTab == 1) {
      this.data.currentTab = '支付宝'
    } else if (this.data.currentTab == 2) {
      this.data.currentTab = '银行卡'
    } else if (this.data.currentTab == 3) {
      this.data.currentTab = '余额'
    }
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/withdraw.html",
      data: {
        openid: app.globalData.openId,
        amount: this.data.money,
        method: this.data.currentTab,
        bank: this.data.name,
        account: this.data.accountNumber,
        name: this.data.userName,
      },
      success: function (res) {
        that.setData({
          withdrawCash: res.data.data
        })
      }
    })
    wx.navigateTo({
      url: '/pages/distribution-center/distribution-center'
    })
  },
  zhiNameTap:function(e){
    this.setData({
      userName: e.detail.value
    })
  },
  zhiNumberTap:function(e){
    this.setData({
      accountNumber: e.detail.value
    })
  },
  // 支付方式(银行卡)
  yinTap:function(){
    let userName = this.data.userName;
    if (!userName || userName.length <= 0) {
      wx.showToast({
        title: '请输入正确的姓名',
        icon: "none"
      })
      return;

    };
    let name = this.data.name;
    if (!name || name.length <= 0) {
      wx.showToast({
        title: '请输入正确的银行名称',
        icon: "none"
      })
      return;
    };
    let accountNumber = this.data.accountNumber;
    if (!accountNumber || accountNumber.length <= 0) {
      wx.showToast({
        title: '请输入正确的银行卡号',
        icon: "none"
      })
      return;
    };
    let money = this.data.money;
    money = parseFloat(money);
    typeof (money);
    const canUseAmount = this.data.canUseAmount || '';
    if (!money || money < 1 || money >= canUseAmount) {
      wx.showToast({
        title: '请输入规定提现金额',
        icon: "none"
      })
      return;
    };
    var that = this;
    if (this.data.currentTab == 0) {
      this.data.currentTab = '微信'
    } else if (this.data.currentTab == 1) {
      this.data.currentTab = '支付宝'
    } else if (this.data.currentTab == 2) {
      this.data.currentTab = '银行卡'
    } else if (this.data.currentTab == 3) {
      this.data.currentTab = '余额'
    }
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/withdraw.html",
      data: {
        openid: app.globalData.openId,
        amount: this.data.money,
        method: this.data.currentTab,
        bank: this.data.name,
        account: this.data.accountNumber,
        name: this.data.userName,
      },
      success: function (res) {
        that.setData({
          withdrawCash: res.data.data
        })
      }
    })
    wx.navigateTo({
      url: '/pages/distribution-center/distribution-center'
    })
  },
 yinUsernameTap: function (e) {
    this.setData({
      userName: e.detail.value
    })
  },
  yinNameTap: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  yinNumberTap: function (e) {
    this.setData({
      accountNumber: e.detail.value
    })
  },
  // 提现方法(余额)
  yuTap:function(){
    let money = this.data.money;
    money = parseFloat(money);
    typeof (money);
    const canUseAmount = this.data.canUseAmount || '';
    if (!money || money < 1 || money >= canUseAmount) {
      wx.showToast({
        title: '请输入规定提现金额',
        icon: "none"
      })
      return;
    };
    var that = this;
    if (this.data.currentTab == 0) {
      this.data.currentTab = '微信'
    } else if (this.data.currentTab == 1) {
      this.data.currentTab = '支付宝'
    } else if (this.data.currentTab == 2) {
      this.data.currentTab = '银行卡'
    } else if (this.data.currentTab == 3) {
      this.data.currentTab = '余额'
    }
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/withdraw.html",
      data: {
        openid: app.globalData.openId,
        amount: this.data.money,
        method: this.data.currentTab,
        bank: this.data.name,
        account: this.data.accountNumber,
        name: this.data.userName,
      },
      success: function (res) {
        that.setData({
          withdrawCash: res.data.data
        })
      }
    })
    wx.navigateTo({
      url: '/pages/distribution-center/distribution-center'
    })
  },
  // 提现金额
  moneyTap:function(e){
     this.setData({
       money:e.detail.value
     });
  },
})