// goods.js 
//var api = require('../../api.js');
var utils = require('../../utils.js');
var pageable = require("../../utils/pageable.js");
var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');
var p = 1;
var is_loading_comment = false;
var is_more_comment = true;
var share_count = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isCar:false,
    pageNumber: 0,
    pageSize: 10,
    collect: '',
    productId: '',
    price: '',
    id: null,
    goods: {},
    show_attr_picker: false,
    form: {
      number: 1,
    },
    tab_detail: "active",
    tab_comment: "",
    comment_list: [{}, {}],
    comment_count: {
      score_all: 0,
      score_3: 0,
      score_2: 0,
      score_1: 0,
    },
    autoplay: false,
    hide: "hide",
    show: false,
    x: wx.getSystemInfoSync().windowWidth,
    y: wx.getSystemInfoSync().windowHeight - 20,
    stock: '',
    sales: '',
    products: []
    //demo
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    share_count = 0;
    p = 1;
    is_loading_comment = false;
    is_more_comment = true;
    // this.setData({
    //   store: wx.getStorageSync('store'),
    // });
    var parent_id = 0;
    var page = this;
    page.setData({
      id: options.id,
      pageNumber: 0,
    });
    page.getGoods();
  },

  //下拉事件 
  onReachBottom: function() {
    // console.log("pk")
    if (this.data.tab_comment === 'active') {
      this.getEvaluateList()
    };
  },

  getGoods: function() {
    var page = this;
    wx.request({
      url: app.globalData.address + '/api/goods/detail.html',
      data: {
        openid: app.globalData.openId,
        goodsId: page.data.id,
      },
      success: function(res) {
        //demo
        if (res.data.code == 0) {
          var detail = res.data.data.introduction;
          if (detail) {
            WxParse.wxParse("detail", "html", detail, page);
          }
          page.isCarRequest(res.data.data.defaultProduct.id)
          page.setData({
            price: res.data.data.defaultProduct.price,
            products: res.data.data.products ? res.data.data.products : [],
            sales: res.data.data.sales,
            stock: res.data.data.stock,
            goods: res.data.data,
            attr_group_list: res.data.data.data,
            buyid: res.data.data.defaultProduct.id,
            productId: res.data.data.defaultProduct.id,
            collect: res.data.data.collect,
            
          });
        }
        if (res.data.code == 1) {
          wx.showModal({
            title: "提示",
            content: res.data.msg,
            showCancel: false,
            success: function(res) {
              if (res.confirm) {
                wx.switchTab({
                  url: "/pages/index/index"
                });
              }
            }
          });
        }
      }
    });
  },


  //得到评论列表
  getEvaluateList: function() {
    var that = this;
    const url = app.globalData.address + "/api/review/list.html";
    const params = {
      openid: app.globalData.openId,
      goodsId: that.data.id,
    }
    pageable.getPage(that, url, params, 'list', (res) => {
      that.setData({
        // comment_list: res.data.list
      }, that.getImage)
    })
  },

  onGoodsImageClick: function(e) {
    var page = this;
    var urls = [];
    var index = e.currentTarget.dataset.index;
    for (var i in page.data.goods.productimages) {
      urls.push(page.data.goods.productimages[i].source);
    }
    wx.previewImage({
      urls: urls, // 需要预览的图片http链接列表
      current: urls[index],
    });
  },



  numberSub: function() {
    var page = this;
    var num = page.data.form.number;
    var goods = page.data.goods;
    if (num <= goods.mixBuy )
      return true;
    num--;
    page.setData({
      form: {
        number: num,
      }
    });
  },

  numberAdd: function() {
    var page = this;
    var num = page.data.form.number;
    num++;
    page.setData({
      form: {
        number: num,
      }
    });
  },

  numberBlur: function(e) {
    var page = this;
    var num = e.detail.value;
    num = parseInt(num);
    if (isNaN(num))
      num = 1;
    if (num <= 0)
      num = 1;
    page.setData({
      form: {
        number: num,
      }
    });
  },

  addCart: function() {
    this.submit('ADD_CART');
  },

  buyNow: function() {
    this.submit('BUY_NOW');
  },

  // 提交
  submit: function(type) {
    var page = this;
    if (!page.data.show_attr_picker) {
      page.showAttrPicker();
      return true;
    }
    if (page.data.form.number > page.data.stock) {
      wx.showToast({
        title: "商品库存不足，请选择其它规格或数量",
        image: "/img/icon-warning.png",
      });
      return true;
    }
    if (page.data.attChecked == false) {
      wx.showToast({
        title: "请选择规格",
        image: "/img/icon-warning.png",
      });
      return true;
    }
    var attr_group_list = page.data.attr_group_list;
    var checked_attr_list = [];
    for (var i in attr_group_list) {
      var attr = false;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].checked) {
          attr = {
            attr_id: attr_group_list[i].attr_list[j].attr_id,
            attr_name: attr_group_list[i].attr_list[j].attr_name,
          };
          break;
        }
      }
      if (!attr) {
        wx.showToast({
          title: "请选择" + attr_group_list[i].attr_group_name,
          image: "/img/icon-warning.png",
        });
        return true;
      } else {
        checked_attr_list.push({
          attr_group_id: attr_group_list[i].attr_group_id,
          attr_group_name: attr_group_list[i].attr_group_name,
          attr_id: attr.attr_id,
          attr_name: attr.attr_name,
        });
      }
    }
    if (type == 'ADD_CART') { //加入购物车 
      wx.showLoading({
        title: "正在提交",
        mask: true,
      });
      wx.request({
        url: app.globalData.address + "/api/cart/add.html",
        data: {
          openid: app.globalData.openId,
          productId: page.data.productId,
          //attr: JSON.stringify(checked_attr_list),
          quantity: page.data.form.number,
        },
        success: function(res) {
          wx.hideLoading();
          if (res.data.code === 0) {
            page.isCarRequest(page.data.productId);
            wx.showToast({
              title: '加入购物车成功',
              icon: 'success',
              duration: 1000
            })
            page.setData({
              show_attr_picker: false,
            });

          } else {
            wx.showToast({
              title: res.data.msg,
              icon: "none",
              duration: 1000,
            })
            page.setData({
              show_attr_picker: true,
            });
          }


        }
      });
    }
    if (type == 'BUY_NOW') { //立即购买 
      page.setData({
        show_attr_picker: false,
      });
      wx.redirectTo({
        url: "/pages/order-submit/order-submit?goods_info=" + JSON.stringify({
          goods_id: page.data.productId,
          attr: checked_attr_list,
          num: page.data.form.number,
        }),
      });
    }

  },

  hideAttrPicker: function() {
    var page = this;
    page.setData({
      show_attr_picker: false,
    });
  },

  showAttrPicker: function() {
    var page = this;
    var attr_group_list = page.data.attr_group_list;
    if (attr_group_list) {
      if (attr_group_list.length == 1) {
        if (attr_group_list[0].attr_list.length == 1) {
          attr_group_list[0].attr_list[0].checked = true;
        }
      }
    }
    page.setData({
      show_attr_picker: true,
      attr_group_list: attr_group_list,
    });
  },

  attrClick: function(e) {
    var page = this;
    var attr_group_id = e.target.dataset.groupId;
    var attr_id = e.target.dataset.id;
    var attr_group_list = page.data.attr_group_list;


    for (var i in attr_group_list) {
      if (attr_group_list[i].attr_group_id != attr_group_id)
        continue;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].attr_id == attr_id) {
          attr_group_list[i].attr_list[j].checked = true;
        } else {
          attr_group_list[i].attr_list[j].checked = false;
        }
      }
    }

    page.setData({
      attr_group_list: attr_group_list,
    });

    var check_attr_list = [];
    var check_all = true;
    for (var i in attr_group_list) {
      var group_checked = false;
      for (var j in attr_group_list[i].attr_list) {
        if (attr_group_list[i].attr_list[j].checked) {
          check_attr_list.push(attr_group_list[i].attr_list[j].attr_name);
          group_checked = true;
          break;
        }
      }
      if (!group_checked) {
        check_all = false;
        break;
      }
    }
    if (!check_all)
      return;
    //判断规格对应的货品
    var products = page.data.products;

    for (var k = 0; k < products.length; k++) {
      var sameProduct = true
      for (var l = 0; l < products[k].specificationValues.length; l++) {

        if (check_attr_list[l] != page.data.products[k].specificationValues[l].value) {

          sameProduct = false
        }
      }
      if (sameProduct == true) {
        page.setData({
          productId: page.data.products[k].id,
          price: page.data.products[k].price,
        })
        sameProduct = false;
        break;
      }
    }

    //获取该规格货品库存
    wx.request({
      url: app.globalData.address + '/api/goods/stock.html',
      data: {
        openid: app.globalData.openId,
        productid: page.data.productId
      },
      success: function(res) {
        page.setData({
          stock: res.data.data,
        })
      }
    })

  },


  // 收藏
  favoriteAdd: function() {
    var page = this;
    wx.request({
      url: app.globalData.address + "/api/goods/collect.html",
      method: "GET",
      data: {
        openid: app.globalData.openId,
        goodsid: page.data.id,
      },
      success: function(res) {
        if (res.data.msg === "success") {
          page.setData({
            collect: true,
          });
          wx.showToast({
            title: '收藏成功',
            type: "success",
          })
        }
      }
    });
  },
  // 取消收藏
  favoriteRemove: function() {
    var page = this;
    wx.request({
      url: app.globalData.address + "/api/goods/cancelCollect.html",
      method: "GET",
      data: {
        openid: app.globalData.openId,
        goodsid: page.data.id,
      },
      success: function(res) {
        if (res.data.msg === "success") {
          page.setData({
            collect: false,
          });
          wx.showToast({
            title: '取消收藏成功',
            type: "success",
          })

        }
      }
    });
  },
  // 详情和评论的转化
  tabSwitch: function(e) {
    var page = this;
    var tab = e.currentTarget.dataset.tab;
    if (tab == "detail") {
      page.setData({
        tab_detail: "active",
        tab_comment: "",
      });
    } else {
      page.setData({
        tab_detail: "",
        tab_comment: "active",
        pageNumber: 0,
        pageSize: 10,
      });
      page.getEvaluateList()

    }
  },

  commentPicView: function(e) {
    var page = this;
    var index = e.currentTarget.dataset.index;
    var pic_index = e.currentTarget.dataset.picIndex;
    wx.previewImage({
      current: page.data.comment_list[index].pic_list[pic_index],
      urls: page.data.comment_list[index].pic_list,
    });
  },

  getImage: function() {
    var list = this.data.comment_list

    for (var i = 0; i < list.length; i++) {
      var images = [];

      if (list[i].imgSrc1 != null) {
        images.push(list[i].imgSrc1)
      }
      if (list[i].imgSrc2 != null) {
        images.push(list[i].imgSrc2)
      }
      if (list[i].imgSrc3 != null) {
        images.push(list[i].imgSrc3)
      }
      if (list[i].imgSrc4 != null) {
        images.push(list[i].imgSrc4)
      }
      if (list[i].imgSrc5 != null) {
        images.push(list[i].imgSrc5)
      }
      if (list[i].imgSrc6 != null) {
        images.push(list[i].imgSrc6)
      }
      if (list[i].imgSrc7 != null) {
        images.push(list[i].imgSrc7)
      }
      if (list[i].imgSrc8 != null) {
        images.push(list[i].imgSrc8)
      }
      if (list[i].imgSrc9 != null) {
        images.push(list[i].imgSrc9)
      }
      list[i].images = images;
    }

    this.setData({
      comment_list: list,
    }, () => {})
  },



  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    const path = `/pages/index/index?goodId=${this.data.id}`;
    // return app.sharePage(path);
    return {
      title: this.data.goods.name,
      path: path,
      imageUrl: this.data.goods.image,
    }
  },


  play: function(e) {
    var url = e.target.dataset.url; //获取视频链接
    this.setData({
      url: url,
      hide: '',
      show: true,
    });
    var videoContext = wx.createVideoContext('video');
    videoContext.play();
  },

  close: function(e) {
    if (e.target.id == 'video') {
      return true;
    }
    this.setData({
      hide: "hide",
      show: false
    });
    var videoContext = wx.createVideoContext('video');
    videoContext.pause();
  },


  hide: function(e) {
    if (e.detail.current == 0) {
      this.setData({
        img_hide: ""
      });
    } else {
      this.setData({
        img_hide: "hide"
      });
    }
  },


  getGoodsQrcode: function() {
    var page = this;
    page.setData({
      goods_qrcode_active: "active",
      share_modal_active: "",
    });
    if (page.data.goods_qrcode)
      return true;
    app.request({
      url: api.default.goods_qrcode,
      data: {
        goods_id: page.data.id,
      },
      success: function(res) {
        if (res.code == 0) {
          page.setData({
            goods_qrcode: res.data.pic_url,
          });
        }
        if (res.code == 1) {
          page.goodsQrcodeClose();
          wx.showModal({
            title: "提示",
            content: res.msg,
            showCancel: false,
            success: function(res) {
              if (res.confirm) {

              }
            }
          });
        }
      },
    });
  },

  goodsQrcodeClose: function() {
    var page = this;
    page.setData({
      goods_qrcode_active: "",
      no_scroll: false,
    });
  },

  saveGoodsQrcode: function() {
    var page = this;
    if (!wx.saveImageToPhotosAlbum) {
      // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。',
        showCancel: false,
      });
      return;
    }

    wx.showLoading({
      title: "正在保存图片",
      mask: false,
    });

    wx.downloadFile({
      url: page.data.goods_qrcode,
      success: function(e) {
        wx.showLoading({
          title: "正在保存图片",
          mask: false,
        });
        wx.saveImageToPhotosAlbum({
          filePath: e.tempFilePath,
          success: function() {
            wx.showModal({
              title: '提示',
              content: '商品海报保存成功',
              showCancel: false,
            });
          },
          fail: function(e) {
            wx.showModal({
              title: '图片保存失败',
              content: e.errMsg,
              showCancel: false,
            });
          },
          complete: function(e) {
            wx.hideLoading();
          }
        });
      },
      fail: function(e) {
        wx.showModal({
          title: '图片下载失败',
          content: e.errMsg + ";" + page.data.goods_qrcode,
          showCancel: false,
        });
      },
      complete: function(e) {
        wx.hideLoading();
      }
    });

  },

  goodsQrcodeClick: function(e) {
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      urls: [src],
    });
  },
  closeCouponBox: function(e) {
    this.setData({
      get_coupon_list: ""
    });
  },
  // 评价图片查看
  clickImage: function(e) {
    const urls = e.currentTarget.dataset.urls
    const index = e.currentTarget.dataset.index

    wx.previewImage({
      urls,
      current: urls[index]
    })
  },
  isCarRequest: function(productId) {
    wx.request({
      url: app.globalData.address+'/api/cart/isCart.html',
      data:{
        goodsId: productId,
        openid:app.globalData.openId,
      },
      success: (res)=>{
        this.setData({
          isCar: res.data,
        })
      }
    })
  }
});