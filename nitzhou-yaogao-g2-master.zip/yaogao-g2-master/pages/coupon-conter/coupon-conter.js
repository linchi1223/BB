// pages/coupon-conter/coupon-conter.js
const app = getApp()
const pageable = require('../../utils/pageable.js')
Page({

  /**
   * 页面的初始数据
   */
  data: { 
  couponpop:false, //控制弹窗数据
  used:false,
  pageNumber: 0,
  pageSize: 5
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    this.getPageItem()
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

 

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getPageItem()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  /**
   * 获取优惠列表
   */
  getPageItem: function () {
    //const url = `${app.globalData.domain}/coupon/changeList.html`
    const url = app.globalData.address + "/api/coupon/list.html";
    var params={
      openid:app.globalData.openId,
    }
    pageable.getPage(this, url, params, 'list')
  },
/**
 * 得到优惠卷
 */
  givecoupon: function (e) {
    var that= this;
    wx.showToast({
      title: '努力领取中...',
      icon: 'loading',
      mask: true,
      duration: 10000
    })  
    wx.request({
      // url: `${app.globalData.domain}/IntegralLog/exchangeCoupon.html`,
      url: app.globalData.address + "/api/coupon/receivecouponcode.html",
      data: {
        openid: app.globalData.openId,
        couponId: e.currentTarget.dataset.id
      },
      success: function (res) {
       if (res.data.msg == "success"){
         wx.hideToast();
         var couponpop = that.data.couponpop;
        that.setData({
          used:true,
          couponpop: !couponpop,
        }) 
        that.switchBtn(e,that)
       }
       else
       {
         wx.hideToast();
         wx.showToast({
           title: res.data.msg,
           icon: "none"
         });
         
       }
      }
    })
  },
  switchBtn:function(e,that){
    var pageList = this.data.pageList;

    var index = e.currentTarget.dataset.index;
    var str = "pageList["+index+"].checked"
    that.setData({
      [str]:true,
    }) 
  },

  goTouse:function()
{
  wx.switchTab({
    url: '/pages/index/index',
  })
},

// 模拟弹窗
  noticelongtap:function(){
    return;
  },
  ongetCoupons: function () {
    var couponpop = this.data.couponpop;
    this.setData({
      couponpop: !couponpop,
    })
  },
})