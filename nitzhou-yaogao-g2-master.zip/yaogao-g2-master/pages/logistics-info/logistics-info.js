var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order:[],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      orderId: options.orderId,
    });

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          clientHeight: res.windowHeight
        });
      }
    });
    this.logistics()
  },
  showheight:function(that){
    // var that = this;
    var querys=wx.createSelectorQuery();
    querys.selectAll('.wenzi').boundingClientRect(function(res){
      console.log(res);
      that.setData({
        lineHeight: res,
      })
    });
    querys.exec();
    // querys.selectViewport().scrollOffset()
    // querys.exec(function (res) {
    //   console.log(res);
    // })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  logistics:function(){
    var that=this;
    wx.request({
      url: app.globalData.address + '/api/order/transit_step.html',
      data:{
        openid: app.globalData.openId,
        sn: this.data.orderId,
      },
      success:function(res){
      
        that.setData({
          order:res.data
        },()=>{
          that.showheight(that);
        })
      }
    })
  }
})