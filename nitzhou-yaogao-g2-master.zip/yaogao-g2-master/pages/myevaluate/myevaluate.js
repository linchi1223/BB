// pages/myevaluate/myevaluate.js

const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

    params:{},
    content:"",
    imgs: [],
    myurl:[],
    evaluate: {},
    evaluate_contant: ['001'],
    stars: [0, 2, 4, 6, 8],
    normalSrc: '../../img/star24_off@2x.png',
    selectedSrc: '../../img/star24_on@2x.png',
    halfSrc: '../../img/star24_half@2x.png',
    score: 0,
    scores: [0, 0, 0],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  
    let params = JSON.parse(options.params)
    this.setData({
      params:params,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  //点击左边,半颗星
  selectLeft: function (e) {
    var score = e.currentTarget.dataset.score
    if (this.data.score == 1 && e.currentTarget.dataset.score == 1)    {
      score = 0;
    }

    this.data.scores[e.currentTarget.dataset.idx] = score,
      this.setData({
        scores: this.data.scores,
        score: score
      })

  },

  //点击右边,整颗星
  selectRight: function (e) {
    var score = e.currentTarget.dataset.score

    this.data.scores[e.currentTarget.dataset.idx] = score,
      this.setData({
        scores: this.data.scores,
        score: score
      })
  },

  //获取内容
  bindTextAreaChange:function(e){
    var content = e.detail.value;
    this.setData({
      content:content,
    })
  },


  // 提交事件
  submit_evaluate: function (e) {
    if(!this.data.params.productId)
    {
      wx.showToast({
        title: '商品该规格已下架,无法评价',
        icon:'none',
        mask:true,
        duration:1200,
      })
      return;
    }
    this.loadPicture(e);
  },


  /**
 * 上传图片
 */
  chooseImg: function (e) {
    var that = this;
    if (that.data.imgs.length == 9) {
      wx.showModal({
        title: '提醒',
        content: "最多只能上传9张",
        showCancel: false
      })
      return
    }
    var imgs = this.data.imgs;
    if (imgs.length >= 9) {
      this.setData({
        lenMore: 1
      });
      setTimeout(function () {
        that.setData({
          lenMore: 0
        });
      }, 2500);
      return false;
    }
    wx.chooseImage({
      count: 9,
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        var imgs = that.data.imgs;
        for (var i = 0; i < tempFilePaths.length; i++) {
          if (imgs.length >= 9) {
            that.setData({
              imgs: imgs
            });
            return false;
          } else {
            imgs.push(tempFilePaths[i]);
          }
        }
        that.setData({
          imgs: imgs
        });
       
      },
      fail:function(res){
      }
    });
  },

  /**
   * 删除图片
   */
  deleteImg: function (e) {
    var imgs = this.data.imgs;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    this.setData({
      imgs: imgs
    });
  },

  /**
   * 预览效果
   */
  previewImg: function (e) {
    //获取当前图片的下标
    var index = e.currentTarget.dataset.index;
    //所有图片
    var imgs = this.data.imgs;
    wx.previewImage({
      //当前显示图片
      current: imgs[index],
      //所有图片
      urls: imgs
    })
  },

  // 将本地地址返回给后台，并提交评价内容。
  loadPicture:function(e){
    var that  =this;
    var imgNum =0;
    let imgs = that.data.imgs;
    if(that.data.content===null||that.data.content==="")
    {
      wx.showModal({
        title: '格式不正确',
        content: '请填写完整信息',
        showCancel: false
      })
      return;
    }
    wx.showToast({
      title: '正在上传...',
      icon: 'loading',
      mask: true,
      duration: 1000
    })
    if(imgs.length===0)
    {
      imgs = [, , , , , , , , ]
      that.setData({
        myurl:imgs,
      })
      that.sunmbitEvaluate(that,e);
    }
    else{
      for (let i = 0; i < imgs.length; i++) {
        wx.uploadFile({
          url: app.globalData.address + '/api/review/uploadImg.html',
          filePath: imgs[i],
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data"
          },
          success: function (res) {
            imgNum++;
            let data = JSON.parse(res.data)
            let url = data.msg;
            that.data.myurl.push(url);
            if (imgNum == imgs.length) {
              that.sunmbitEvaluate(that,e);
            }
          },
        })
      }
    }
  },

  //提交评价接口
  sunmbitEvaluate:function(that,e){
    wx.request({
      url: app.globalData.address+'/api/review/save.html',
      data:{
        imgSrc1: that.data.myurl[0],
        imgSrc2: that.data.myurl[1],
        imgSrc3: that.data.myurl[2],
        imgSrc4: that.data.myurl[3],
        imgSrc5: that.data.myurl[4],
        imgSrc6: that.data.myurl[5],
        imgSrc7: that.data.myurl[6],
        imgSrc8: that.data.myurl[7],
        imgSrc9: that.data.myurl[8],
        productId: that.data.params.productId,
        score: that.data.score,
        content: that.data.content,
        orderItemId: that.data.params.orderItemId,
        openid:app.globalData.openId,
      },
      success:function(res){
       if(res.data){
        //  wx.hideToast();
         if (res.data.code == 0) {
           wx.showToast({
             title: '评价成功',
             icon: 'success',
             duration:2000,
           })
           const page = getCurrentPages();
           const beforepage = page[page.length-2];
           const orderPage = page[page.length - 3]
           if (beforepage.__route__ === "pages/order/order")
           {
             beforepage.received(null);
             beforepage.orderAll(null);
           };
           if (orderPage.__route__ === "pages/order/order")
           {
             orderPage.received(null);
             orderPage.orderAll(null);
           }
           if (beforepage.__route__ === "pages/carOrderEvaluate/carOrderEvaluate")
           {
             var str = "order.orderItems[" + that.data.params.index +"].review";
             beforepage.getOrder(beforepage.data.sn);
             beforepage.setData({
               str:true,
               evaed:true,
             })
           }

           if (beforepage.__route__ === "pages/waitevaluate/waitevaluate") {
             beforepage.toDetail();
           }
           setTimeout(()=>{
             wx.navigateBack();
           },1000)
         }
         else{
           wx.showModal({
             title: '评价失败',
             content: res.data.content,
             showCancel: false
           })
          //  that.setData({
          //    imgs: null
          //  });
           return
         }
       }

      }
    })
  } ,
})