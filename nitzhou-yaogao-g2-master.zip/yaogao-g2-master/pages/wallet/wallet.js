// pages/wallet/wallet.js
const app = getApp();
const pageable = require("../../utils/pageable.js");
Page({
  data: {
    pageNumber:0,
    pageSize:5,
    money:0,
  },
  onLoad: function () {

    this.getMoney();
    this.getPayList();
  },

  gotoRecharge:function(){
    wx.navigateTo({
      url: '/pages/balance-recharge/balance-recharge',
    })
  },


  getMoney:function(){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/user/balance.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        that.setData({
          money: res.data,
        })
      }
      
    })
  },

  // getPayList:function(){
  //   var that = this;

  //   var url = app.globalData.address +"/api/user/list.html";
  //   var params={
  //     openid:app.globalData.openId,
  //   }
  //   pageable.getPage(that,url,params,'content',(res)=>{
     
  //   })
  // }
  getPayList:function(){
    var that=this
    wx.request({
      url: app.globalData.address + '/api/user/list.html',
      data:{
        openid: app.globalData.openId,
      },
      success: function (res) {
        that.setData({
          list: res.data
        })
      }
    })
  }
})