// pages/coupon/coupon.js

const app = getApp()
const pageable = require('../../utils/pageable.js')

Page({
  data: {
    currentIndex: "unused",
    expired: 0,
    unused: 0,
    used: 0,
    pageNumber: 0,
    pageSize: 10
  },
  onLoad: function (options) {

  },
  onReachBottom: function () {
    this.getPageItem()
  },
  onShow: function () {

    this.setData({
      pageNumber: 0
    }, this.getPageItem)
  },
  clickTopTar: function (e) {
    const status = e.target.dataset.status

    if (this.data.currentIndex === status) {

      return
    }

    this.setData({
      pageNumber: 0,
      currentIndex: status
    }, this.getPageItem)
  },
  goToCouponconter: function () {
    wx.navigateTo({
      url: '/pages/coupon-conter/coupon-conter',
    })
  },

  getPageItem: function () {
    const url = `${app.globalData.address}/api/coupon/personalcoupon.html`
    const params = {
      openid:app.globalData.openId ,
      status: this.data.currentIndex,
    };
    pageable.getPage(this, url, params, 'list', (res) => {

      this.setData({
        expired: res.data.expired,
        unused: res.data.unused,
        used: res.data.used
      })
    })
  }
})