//index.js 
//获取应用实例
const pageable = require('../../utils/pageable.js')
var app = getApp();
var refreshNum = 0;

Page({
  data: {
    sharePop: false,
    sharePrice:0,
    newUser: false,
    hotlineAndService:{},
    couponStyle:0, //优惠券的类型
    couriershow:false, //控制类型2优惠券的显示
    content: '', //公告内容
    hasNotice: false, //控制查看公告的弹窗数据
    getCoupon: false, //控制领取优惠券弹窗数据
    couponBackground1: "url(https://tooth.vverp.com/resources/icon/coupons2.png) no-repeat center;",
    couponBackground2: "url(https://tooth.vverp.com/resources/icon/coupongeted.png) no-repeat center;",
    pageNumber: 0,
    pageSize: 3,
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    loadingHidden: false, // loading
    swiperCurrent: 0, //轮播图圈圈在那个位置
    selectCurrent: 0,
    activeCategoryId: 0,
    categoryId: 0,
    kindIndex: 0,
    toView: "",
    goods: [],
    pagey: 1,
    goodType: [{
      tag: "热销",
      title: "热销商品"
    }, {
      tag: "推荐",
      title: "推荐商品"
    }],
    loadingMoreHidden: true,
    // types: [{ id: 0, img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1527857647383&di=e3bc45808cf6a722f31b1aba05294790&imgtype=0&src=http%3A%2F%2Ffile.digitaling.com%2FeImg%2Flogo%2F20140125%2F20140125220737_37363_320.png", name:"黑人"}],
    noticeList: [],

    coupons: "",
    handpick: [],
    hotgoods: [],
    recommendgoods: [],
    classify: [],
    classifygoods: [],
    title: [],
    couponList:[],
  },

  onShareAppMessage: function() {
    const path = "/pages/index/index?scene=" + app.globalData.inviteCode;
    
    return this.sharePage(path);
  },

  //分享的函数
  sharePage: function(path){
    return {
      title: "VANMAX 口腔护理",
      path: path,
      imageUrl: "https://vverp1.oss-cn-shanghai.aliyuncs.com//uploadFile/c46e3140-98cb-4306-91a3-99884650c424.png",
      success: (res) => {
        console.log(1);
        wx.request({
          url: app.globalData.address + '/api/pointLog/share.html',
          data: {
            openid: app.globalData.openId,
          },
          success: (res) => {
            console.log(res);

            this.setData({
              sharePop:true,
              sharePrice:res.data.data,
            })
          }
        })
      },
      fail: function () {
        console.log(2);
      }
    }
  },

  /**
   * 导航栏功能
   */
  tabClick: function(e) {
    this.setData({
      activeCategoryId: e.currentTarget.id //导航栏的一个标识
    });
    this.getGoodsList(this.data.activeCategoryId); //跳转到内容相对应的页面
  },

  //轮播图一张滑动完成后触发的事件，获取当前轮播图所在位置
  swiperchange: function(e) {
    this.setData({
      swiperCurrent: e.detail.current
    })
  },

  //商品区跳转
  toDetailsTap: function(e) {
    wx.navigateTo({
      url: "/pages/goods-new/goods-new?id=" + e.currentTarget.dataset.id
    })
  },

  // 轮播图跳转
  tapBanner: function(e) {

    if (!e.currentTarget.dataset.id) {
      return;
    }
    if (e.currentTarget.dataset.id != 0) {
      wx.navigateTo({
        url: "/pages/goods-new/goods-new?id=" + e.currentTarget.dataset.id
      })
    }
  },

  //分类跳转
  tocatagory: function(e) {
    var that = this
    var id = 0
    wx.navigateTo({
      url: "/pages/catagory/catagory?id=" + id
    })
  },

  //优惠卷
  gitCoupon: function(e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var coupons = that.data.coupons;
    var coupon = "";
    if (e.currentTarget.dataset.check) {
      return
    }
    wx.request({
      // url: `${app.globalData.domain}/IntegralLog/exchangeCoupon.html`,
      url: app.globalData.address + "/api/coupon/receivecouponcode.html",
      data: {
        openid: app.globalData.openId,
        couponId: e.currentTarget.dataset.id
      },
      success: function(res) {
        if (res.data.msg == "success") {
          var getCoupon = that.data.getCoupon;
          coupons[index].checked = true;
          coupon = coupons[index];
          coupons.splice(index, 1);
          var len = coupons.push(coupon);
          that.setData({
            coupons: coupons,
            getCoupon: !getCoupon,
          })

          // that.switchBtn(e, that)
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: "none"
          });

        }
      }
    })

  },
 

  bindTypeTap: function(e) {
    this.setData({
      selectCurrent: e.index
    })
  },

  // scroll: function (e) {
  //   var that = this, scrollTop = that.data.scrollTop;
  //   that.setData({
  //     scrollTop: e.detail.scrollTop
  //   })
  // },

  onLoad: function(options) {
    // wx.showShareMenu({
    //   withShareTicket: true,
    // })

    if (options.scene) {
      app.userLogin(options.scene)
    } else {
      app.userLogin();
    }
    // this.getExhibition();
    wx.getSetting({
      success: res => {

        // if (res.authSetting['scope.userLocation']) {
        //   this.getExhibition();
        // } else {
        //   this.getExhibition();
        // }
        this.getExhibition();
        
        if (res.authSetting['scope.userInfo']) {
          if (options.goodId) {
            wx.navigateTo({
              url: `/pages/goods-new/goods-new?id=${options.goodId}`,
            })
          }
        } else {
          const str = JSON.stringify(options)
          wx.reLaunch({
            url: `/pages/auth-login/auth-login?params=${str}`
          })
        }
      }
    })
    var that = this
    that.getBanners();

    that.getNotice();
  },

  /**
   * 后台请求轮播图
   */
  getBanners: function() {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/ad/list.html',
      success: function(res) {
        that.setData({
          banners: res.data.data
        });
      }
    })
  },
  onShow: function() {
    this.iconList();
    this.setData({
      pageNumber: 0,
      pageSize: 3,
    })
    if (app.globalData.openId) {
      this.getCouponList(app.globalData.openId);
      this.carRequest();
    }
  },

  //下拉刷新
  onPullDownRefresh: function() {
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userLocation']) {
          this.getExhibition();
        } else {
          this.getExhibition();
        }
      }
    })
    // this.gethotgood();

  },

  legalPullDpwnCount: function() {
    if (refreshNum === 0) {
      wx.stopPullDownRefresh();
    }
  },

  // 请求地理位置并设置是否存在展会
  getExhibition: function() {
    var that = this;
    refreshNum = refreshNum + 1;
    wx.getLocation({
      type: 'wgs84',
      success: function(res) {
        wx.request({
          url: app.globalData.address + '/api/exhibition/isExhibition.html',
          data: {
            latitude: res.latitude,
            longitude: res.longitude,
          },
          success: function(res) {

            refreshNum = refreshNum - 1;
            that.legalPullDpwnCount();
            app.globalData.exhibitionId = res.data.data.exhibitionId;

            that.getRequests(that);
            if (res.data.data.exhibitionId != 1) {
              if (res.data.data.content) {
                that.setData({
                  hasNotice: true,
                  content: res.data.data.content,
                })
              }
            } else {
              that.getSpecialNotice();
            }
          }
        })
      },
    })
  },

  // 众多请求(防止exhibitionId为空)
  getRequests: function(that) {
    if (app.globalData.openId) {
      that.setData({
        pageNumber: 0
      })

      that.getclassify();
      that.gettitle();
      that.hotlineAndServiceRequset();
      that.couponStyleRequest();
      that.carRequest();
      if(app.globalData.isNew)
      {
        that.getUserNewCoupon();
      }
      
      // that.gethotgood();
      // that.gethandpick();
      // that.getrecommendgood();


    } else {
      app.openIdReadyCallback = (res) => {
        let openId = res.data.data.openid
        let isNew = res.data.data.isNew
        that.couponStyleRequest(openId);
        that.hotlineAndServiceRequset(openId)
        that.getclassify(openId);
        that.gettitle(openId);
        that.carRequest(openId);
        if (res.data.data.isNew) {
          that.getUserNewCoupon(openId,isNew);
        }
        // that.gethotgood();
        // that.gethandpick();
        // that.getrecommendgood();


      }
    };
  },


  /**
   * 搜索框区域功能
   */
  toSearch: function() {
    wx.navigateTo({
      url: "/pages/home-search/home-search"
    })
  },

  /**
   * 底部加载
   */
  onReachBottom: function() {
    var goods = this.data.goods
    var pagey = this.data.pagey + 1
    var that = this
    wx.request({
      url: app.globalData.address + '/api/goods/list.html',
      data: {
        pageSize: 4,
        pageNumber: pagey,
        openid: app.globalData.openId,
        exhibitionId: app.globalData.exhibitionId

      },
      success: function(res) {
        if (pagey <= res.data.data.totalPages) {
          for (var i = 0; i < res.data.data.content.length; i++) {
            goods.push(res.data.data.content[i]);
          }
        } else {
          that.setData({
            loadingMoreHidden: false
          })
        }
        that.setData({
          goods: goods,
          pagey: pagey
        })
      }
    })
  },

  /**
   * 后台请求公告函数
   */
  getNotice: function() {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/article/list.html',
      success: function(res) {
        that.setData({
          noticeList: res.data.data
        });
      }
    })
  },

  // /**
  //  * 获取导航栏
  //  */
  // gethandpick: function(){
  //   var that = this;
  //   var handpick = that.data.handpick
  //   wx.request({
  //     url: 'https://tooth.vverp.com/api/productCategory/list.html',
  //     success(res) {
  //       for (var i = 0; i < res.data.data.length; i++) {
  //         if (i < 4) {
  //           handpick.push(res.data.data[i]);
  //         }
  //       }
  //       that.setData({
  //         handpick: handpick
  //       })
  //     }
  //   });
  // },

  // 热销（推荐、新品）标题
  gettitle: function(openid=app.globalData.openId) {
    var that = this;
    refreshNum = refreshNum + 1;
    wx.request({
      url: app.globalData.address + '/api/tag/ishome.html',
      data: {
        openid: openid,
      },
      success: function(res) {
        that.gethotgood(res.data.data)
        refreshNum = refreshNum - 1;
        that.legalPullDpwnCount();
        that.setData({
          title: res.data.data,

        })
      }
    })
  },

  /**
   * 热销（推荐、新品商品
   */
  gethotgood: function(title) {
    var title = title;
    var that = this;
    for (var item in title) {
      that.getgoodrequest(that, item, title);
    }

  },
  getgoodrequest: function(that, item, title) {
    var hotgoods = [];
    refreshNum = refreshNum + 1;

    wx.request({
      url: app.globalData.address + '/api/goods/tag.html',
      data: {
        openid: app.globalData.openId,
        tag: title[item].name,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function(res) {
        var titleitem = 'title[' + item + '].list';

        refreshNum = refreshNum - 1;
        that.legalPullDpwnCount();

        for (var i = 0; i < res.data.list.length; i++) {
          if (i < title[item].quantity) {
            hotgoods.push(res.data.list[i]);
          }
        }
        that.setData({
          [titleitem]: hotgoods,

        })

      }
    })
  },

  // 分类显示(标题)
  getclassify: function(openid=app.globalData.openId) {
    var that = this
    refreshNum = refreshNum + 1;
    wx.request({
      url: app.globalData.address + '/api/productCategory/ishome.html',
      data: {
        openid: openid,
      },
      success: function(res) {
        refreshNum = refreshNum - 1;
        that.legalPullDpwnCount();

        that.setData({
          classify: res.data.data,
        }, that.getclassifygoods(res.data.data))
      }
    })
  },

  // 分类内容显示
  getclassifygoods: function(classify) {
    var classify = classify;
    var that = this;
    for (var item in classify) {
      that.getclassifyrequest(that, item, classify);
    }

  },

  getclassifyrequest: function(that, item, classify) {
    var classifygoods = [];

    var newClassify = classify;
    refreshNum = refreshNum + 1;
    wx.request({
      url: app.globalData.address + '/api/goods/list.html',
      data: {
        openid: app.globalData.openId,
        categoryId: classify[item].id,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function(res) {
        var classifyitem = 'classify[' + item + '].list';
        refreshNum = refreshNum - 1;
        that.legalPullDpwnCount();

        for (var i = 0; i < res.data.data.content.length; i++) {
         
          if (i < classify[item].quantity) {
            classifygoods.push(res.data.data.content[i]);
          }
        }
        if (res.data.data.content.length != 0) {
          that.setData({
            [classifyitem]: classifygoods,
          })
        } else {
          newClassify.splice(item, 1);
          
          that.setData({
            classify: newClassify,
            newClassify: newClassify,
          })
        }


        // that.getclassify(res.data.data[0].id)
      }
    })
  },


  // 得到首页优惠券列表
  getCouponList: function(openId) {
    var that = this;
    const url = app.globalData.address + "/api/coupon/list.html";
    var params = {
      pageNumber: 1,
      pageSize: 3,
      openid: openId,
    }
    refreshNum = refreshNum + 1;
    pageable.getPage(this, url, params, 'list', (res) => {
      var list = res.data.list;
      for (var i = 0; i < list.length; i++) {
        if (list[i].priceExpression) {
          list[i].check = 'price';
          list[i].subNumber = list[i].priceExpression;
        } else {
          list[i].subNumber = 0;
        }
      }

      refreshNum = refreshNum - 1;
      that.legalPullDpwnCount();

      this.setData({
        coupons: list,

      })
    })
  },

  // 热销商品页面跳转
  hotgoodsTap: function(e) {
    wx.navigateTo({
      url: '/pages/hotgoods/hotgoods?tag=' + e.currentTarget.dataset.name,
    })
  },
  
  // 分类商品页面跳转
  recommendgoodsTap: function(e) {
    wx.navigateTo({
      url: '/pages/recommendgoods/recommendgoods?categoryId=' + e.currentTarget.dataset.id,
    })
  },

  toarticle: function(e) {
    var index = e.currentTarget.dataset.index;
    var notice = this.data.noticeList[index];
    this.setData({
      hasNotice: true,
      content: notice.content,
    })

  },

  // 模拟弹窗的滑动事件
  noticelongtap: function() {
    return;
  },

  onreadNotice: function() {
    var hasNotice = this.data.hasNotice;
    this.setData({
      hasNotice: !hasNotice,
    })
  },

  ongetCoupons: function() {
    var getCoupon = this.data.getCoupon;
    this.setData({
      getCoupon: !getCoupon,
    })
  },
  // 图标请求后台数据
  iconList: function() {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/memberserving/ishome.html ',
      data: {
        openid: app.globalData.openId,
      },
      success: function(res) {
        that.setData({
          icon: res.data.data,
        })
      }
    })
  },
  getSpecialNotice: function() {
    var that = this;
    if (app.globalData.exhibitionId != 1 && app.globalData.exhibitionId) {
      return;
    }
    wx.request({
      url: app.globalData.address + '/api/article/pop.html',
      success: function(res) {
        if (res.data.code == 0) {
          if (res.data.data.content) {
            that.setData({
              hasNotice: true,
              content: res.data.data.content,
            })
          }
        } else {
          that.setData({
            hasNotice: false,
          })
        }
      },
    })
  },

  // 优惠券完成
  finish:function(){
    this.setData({
      couriershow:false,
      newUser: false,
    })
  },


  hidden:function(){
    this.finish();
  },
  
  // 热线和服务
  hotlineAndServiceRequset:function(openid=app.globalData.openId){
    wx.request({
      url: app.globalData.address+'/api/memberserving/serving.html',
      data:{
        openid: openid,
      },
      success: (res)=>{
        
        if(res.data.code==0)
        {
          this.setData({
            hotlineAndService:res.data.data,
          })
        }
      }
    })
  },
  // 优惠券类型
  couponStyleRequest:function(openid=app.globalData.openId)
  {
    wx.request({
      url: app.globalData.address +'/api/couponstyle/couponstyle.html',
      data:{
        openid:openid,
      },
      success:(res)=>{
        if(res.data.code==0)
        {
          var couponStyle= res.data.data;
          this.setData({
            couponStyle: couponStyle, 
           
          })
          
          if(couponStyle==1)
          {
            
            this.getCouponList(openid);
          }
          else if(couponStyle==2){
          
            this.getCouponList2(openid);
          }
        }
      }
    })
  },

  // 获取类型2优惠券列表
  getCouponList2:function(openid){
    wx.request({
      url: app.globalData.address + "/api/coupon/list2.html",
      data:{
        openid:openid,
      },
      success:(res)=>{
        this.setData({
          couponList: res.data.list,
        })
      }
    })
  },

  goToCouponList:function(){
    var couponStyle= this.data.couponStyle;
    if(couponStyle==1)
    {
      wx.navigateTo({
        url: '/pages/coupon-conter/coupon-conter',
      })
    }
    else if(couponStyle==2)
    {
      this.setData({
        couriershow : true,
      })
    }
  },
  
// 判断购物车中是否有商品
  carRequest:function(openid = app.globalData.openId)
  {
    wx.request({
      url: app.globalData.address +'/api/cart/isCartNull.html',
      data:{
        openid:openid,
        exhibitionId:app.globalData.exhibitionId,
      },
      success:function(res){
        if(!res.data)
        {
          wx.showTabBarRedDot({
            index: 3,
          })
        }
        else{
          wx.hideTabBarRedDot({
            index: 3,
          })
        }
      }
    })
  },

  // 领取新版优惠券
  getUserNewCoupon:function(openId = app.globalData.openId,isNew = app.globalData.isNew){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/coupon/send.html',
      data:{
        openid: openId,
        isGift: isNew,
      },
      success:function(res){
        console.log(res.data.list)
        if(res.data.list.length>0)
        {
          that.setData({
            UserNewCoupon: res.data.list,
            newUser: true,
          })
        }
        
      }
    })
  },
  goToHotgoods:function(){
    wx.navigateTo({
      url: '/pages/hotgoods/hotgoods?tag=' + '推荐',
    })
    this.setData({
      sharePop: false,
    })
  }

})