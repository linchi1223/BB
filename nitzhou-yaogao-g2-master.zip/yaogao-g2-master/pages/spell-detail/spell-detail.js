Page({

  /**
   * 页面的初始数据
   */
  data: {
    test:[0],
    test1:false,
    test3: [0,1,3,4,5,5,7,8,6],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },
  onShareAppMessage: function(){
    console.log("1")
    // return {
    //   title: '自定义转发标题',
    //   path: '/page/user?id=123'
    // }
  },

  goToInstruction: function(){
    wx.navigateTo({
      url: '/pages/spell-instruction/spell-instruction',
    })
  }





})