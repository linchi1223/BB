// pages/inforDeli/inforDetail.js

var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {

  },
  onLoad: function (options) {
    const id = options.id
    const hasRead = options.hasRead
    const index = options.index

    this.getInformationDetail(id)

    if (!hasRead || hasRead === 'false') {
      const pages = getCurrentPages()
      const beforePage = pages[pages.length - 2]

      if (beforePage.__route__ === 'pages/information/information') {
        let pageList = beforePage.data.pageList

        pageList[index].hasRead = true

        beforePage.setData({
          pageList
        })
      }
    }
  },
  getInformationDetail: function (msgId) {
    wx.request({
      url: `${app.globalData.address}/api/article/detail.html`,
      data: {
        msgId,
        // userId: app.globalData.userId
        openid: this.globalData.openId,
      },
      success: (res) => {
        if (res.data) {
          this.setData({
            notice: res.data.message
          });
          WxParse.wxParse('article', 'html', res.data.message.content, this, 5);
        }
      }
    })
  }
})