//index.js 
const app = getApp()
Page({
  data: {
    goodsList: {
      saveHidden: true,
      totalPrice: 0,
      allSelect: true,
      noSelect: false,
      list: []
    },
    delBtnWidth: 120,    //删除按钮宽度单位（rpx）
    editNum:false,
    index:0,
  },

  //获取元素自适应后的实际宽度
  getEleWidth: function (w) {
    var real = 0;
    try {
      var res = wx.getSystemInfoSync().windowWidth;
      var scale = (750 / 2) / (w / 2);  //以宽度750px设计稿做宽度的自适应
      real = Math.floor(res / scale);
      return real;
    } catch (e) {
      return false;
    }
  },

  initEleWidth: function () {
    var delBtnWidth = this.getEleWidth(this.data.delBtnWidth);
    this.setData({
      delBtnWidth: delBtnWidth
    });
  },

  onLoad: function () {
    this.initEleWidth();
    this.onShow();
  },
  onShow: function () {
    var that = this
    var shopList = [];
    // 获取购物车数据请求  
    if (app.globalData.openId != '') {
      wx.request({
        url: app.globalData.address + '/api/cart/list.html',
        data: {
          openid: app.globalData.openId,
          exhibitionId:app.globalData.exhibitionId,
        },
        success: function (res) {

          var shopCarInfoMem = res.data.data;
          if (shopCarInfoMem && shopCarInfoMem.cartItems) {
            shopList = shopCarInfoMem.cartItems;
          }
          that.setData({
            "goodsList.saveHidden": true,
            "goodsList.list": shopList,
          })
          that.setGoodsList(that.getSaveHide(), that.totalPrice(), that.allSelect(), that.noSelect(), shopList)
        }
      })
    }
  },


  touchS: function (e) {
    if (e.touches.length == 1) {
      this.setData({
        startX: e.touches[0].clientX
      });
    }
  },

  touchM: function (e) {
    var index = e.currentTarget.dataset.index;

    if (e.touches.length == 1) {
      var moveX = e.touches[0].clientX;
      var disX = this.data.startX - moveX;
      var delBtnWidth = this.data.delBtnWidth;
      var left = "";
      if (disX == 0 || disX < 0) {//如果移动距离小于等于0，container位置不变
        left = "margin-left:0px";
      } else if (disX > 0) {//移动距离大于0，container left值等于手指移动距离
        left = "margin-left:-" + disX + "px";
        if (disX >= delBtnWidth) {
          left = "left:-" + delBtnWidth + "px";
        }
      }
      var list = this.data.goodsList.list;
      if (index != "" && index != null) {
        list[parseInt(index)].left = left;
        this.setGoodsList(this.getSaveHide(), this.totalPrice(), this.allSelect(), this.noSelect(), list);
      }
    }
  },

  touchE: function (e) {

    var index = e.currentTarget.dataset.index;
    if (e.changedTouches.length == 1) {
      var endX = e.changedTouches[0].clientX;
      var disX = this.data.startX - endX;
      var delBtnWidth = this.data.delBtnWidth;
      //如果距离小于删除按钮的1/2，不显示删除按钮 
      var left = disX > delBtnWidth / 2 ? "margin-left:-" + delBtnWidth + "px" : "margin-left:0px";
      var list = this.data.goodsList.list;
      if (index !== "" && index != null) {
        list[parseInt(index)].left = left;
        this.setGoodsList(this.getSaveHide(), this.totalPrice(), this.allSelect(), this.noSelect(), list);

      }
    }
  },

  delItem: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var cargoodId = that.data.goodsList.list[index].id;
    var list = this.data.goodsList.list;
    list.splice(index, 1);
    this.setGoodsList(this.getSaveHide(), this.totalPrice(), this.allSelect(), this.noSelect(), list);
    //请求删除购物车单项
    wx.request({
      url: app.globalData.address + '/api/cart/delete.html',
      data: {
        openid: app.globalData.openId,
        id: cargoodId
      },
      success: function (res) {
       
      }
    })
  },

  selectTap: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var list = that.data.goodsList.list;
    if (index !== "" && index != null) {
      list[parseInt(index)].checked = !list[parseInt(index)].checked;
      that.selectRequset(that, index);
      that.setGoodsList(that.getSaveHide(), that.totalPrice(), that.allSelect(), that.noSelect(), list);
    }
  },

  //勾选方法
  selectRequset: function (that,index) {
    wx.request({
      url: app.globalData.address + '/api/cart/check.html',
      data: {
        id: that.data.goodsList.list[index].id,
        openid:app.globalData.openId,
      },
      success: function (res) {
        if (res.data) {
        }
      }
    })
  }, 



  totalPrice: function () {
    var list = this.data.goodsList.list;
    var total = 0;
    for (var i = 0; i < list.length; i++) {
      var curItem = list[i];
      if (curItem.checked) {
        total += parseFloat(curItem.price) * curItem.quantity;
      }
    }
    total = parseFloat(total.toFixed(2));//js浮点计算bug，取两位小数精度
    return total;
  },


  allSelect: function () {
    var list = this.data.goodsList.list;
    var allSelect = false;
    for (var i = 0; i < list.length; i++) {
      var curItem = list[i];
      if (curItem.checked) {
        allSelect = true;
      } else {
        allSelect = false;
        break;
      }
    }
    return allSelect;
  },

  noSelect: function () {
    var list = this.data.goodsList.list;
    var noSelect = 0;
    for (var i = 0; i < list.length; i++) {
      var curItem = list[i];
      if (!curItem.checked) {
        noSelect++;
      }
    }
    if (noSelect == list.length) {
      return true;
    } else {
      return false;
    }
  },

  
  setGoodsList: function (saveHidden, total, allSelect, noSelect, list) {
    this.setData({
      goodsList: {
        saveHidden: saveHidden,
        totalPrice: total,
        allSelect: allSelect,
        noSelect: noSelect,
        list: list
      }
    });
    var shopCarInfo = {};
    var tempNumber = 0;
    shopCarInfo.shopList = list;
    for (var i = 0; i < list.length; i++) {
      tempNumber = tempNumber + list[i].quantity
    }
    shopCarInfo.shopNum = tempNumber;
    wx.setStorage({
      key: "shopCarInfo",
      data: shopCarInfo
    })
  },

  // 全选的函数
  bindAllSelect: function () {
    var currentAllSelect = this.data.goodsList.allSelect;
    var list = this.data.goodsList.list;
    if (currentAllSelect) {
      for (var i = 0; i < list.length; i++) {
        var curItem = list[i];
        if (curItem.checked)
        {
          this.selectRequset(this,i);
        }
        curItem.checked = false;
      }
    } else {
      for (var i = 0; i < list.length; i++) {
        var curItem = list[i];
        if (!curItem.checked) {
          this.selectRequset(this, i);
        }
        curItem.checked = true;
      }
    }

    this.setGoodsList(this.getSaveHide(), this.totalPrice(), !currentAllSelect, this.noSelect(), list);
  },

  // 数量加的方法
  jiaBtnTap: function (e) {
    var index = e.currentTarget.dataset.index;
    var list = this.data.goodsList.list; 
    var newQuantity;
    var oldQuantity ;

    if (index !== "" && index != null) {
        oldQuantity = list[parseInt(index)].quantity;
        newQuantity = oldQuantity+1;
        //请求后台修改商品数量
      this.editNumRequest(list[parseInt(index)].id, newQuantity, oldQuantity, index)
    }

  },

  // 数量减少的方法。
  jianBtnTap: function (e) {
    var index = e.currentTarget.dataset.index;
    var list = this.data.goodsList.list;
    // var mixBuy = list[index].mixBuy;
    var mixBuy = 1;
    var newQuantity;
    var oldQuantity;

    if (index !== "" && index != null) {
      if (list[parseInt(index)].quantity > mixBuy) {
        oldQuantity = list[parseInt(index)].quantity;
        newQuantity = oldQuantity-1;

        //请求后台修改商品数量
        this.editNumRequest(list[parseInt(index)].id, newQuantity, oldQuantity, index)
      }
    }
  },


  // 修改数量。
  editNumTap: function (e) {
    var index = e.detail.index;
    var list = this.data.goodsList.list;
    var oldQuantity = list[index].quantity;
    var newQuantity;

    if (index !== "" && index != null) {
      newQuantity = e.detail.quantity;

      this.isEditNum(e);
      //请求后台修改商品数量
      this.editNumRequest(list[parseInt(index)].id, newQuantity, oldQuantity,index)
    }
  },

  editNumRequest: function (id, newQuantity, oldQuantity, index){
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/cart/update.html',
      data: {
        id: id,
        openid: app.globalData.openId,
        quantity: newQuantity,
      },
      success: function (res) {
        // console.log(index);
        var list = that.data.goodsList.list;
        if(res.data.code==0)
        {
          list[index].quantity = newQuantity;
        }
        else{
          wx.showToast({
            title: res.data.msg,
            icon:'none',
            duration:1000,
          })
          list[index].quantity= oldQuantity;
        }

        that.setData({
          "goodsList.list": list,
        }, that.setGoodsList(that.getSaveHide(), that.totalPrice(), that.allSelect(), that.noSelect(), list))
      }
    })
  },

  // 编辑
  editTap: function () {
    var that =this;
    var list = that.data.goodsList.list;
    for (var i = 0; i < list.length; i++) {
      var curItem = list[i];
      curItem.checked = false;
    }
    that.setData({
      "goodsList.list":list,
    }, that.setGoodsList(!that.getSaveHide(), that.totalPrice(), that.allSelect(), that.noSelect(), list))
  },

  // 完成
  saveTap: function () {
    var list = this.data.goodsList.list;
    for (var i = 0; i < list.length; i++) {
      var curItem = list[i];
      curItem.checked = true;
    }
    this.setGoodsList(!this.getSaveHide(), this.totalPrice(), this.allSelect(), this.noSelect(), list);
  },

  getSaveHide: function () {
    var saveHidden = this.data.goodsList.saveHidden;
    return saveHidden;
  },

  // 删除
  deleteSelected: function () {
    var page = this;
    var list = this.data.goodsList.list;
    //请求选中删除
    for (let i = 0; i < list.length; i++) {
      let curItem = list[i];

      if (curItem.checked) {

        wx.request({
          url: app.globalData.address + '/api/cart/delete.html',
          data: {
            openid: app.globalData.openId,
            id: curItem.id
          },
          success: function (res) {
            page.carRequest();
          }
        })
      }
    }
    // above codes that remove elements in a for statement may change the length of list dynamically
    list = list.filter(function (curGoods) {
      return !curGoods.checked;
    });
    this.setGoodsList(this.getSaveHide(), this.totalPrice(), this.allSelect(), this.noSelect(), list);
  },

  //结算
  toPayOrder: function () {
    wx.showLoading();
    var that = this;
    if (this.data.goodsList.noSelect) {
      wx.hideLoading();
      return;
    }
    // 重新计算价格，判断库存
    var shopList = [];
    var shopCarInfoMem = wx.getStorageSync('shopCarInfo');
    if (shopCarInfoMem && shopCarInfoMem.shopList) {
      // ???
      // shopList = shopCarInfoMem.shopList.filter(entity => {
      //   return entity.active;
      // });
      shopList = shopCarInfoMem.shopList;
    }
    if (shopList.length == 0) {
      wx.hideLoading();
      return;
    };
    var isFail = false;
    var doneNumber = 0;
    var needDoneNUmber = shopList.length;
    for (let i = 0; i < shopList.length; i++) {
      if (isFail) {
        wx.hideLoading();
        return;
      };
    }
    
    this.navigateToPayOrder();
  },

  navigateToPayOrder: function () {
    var that = this;

    wx.hideLoading();
    wx.navigateTo({
      url: "/pages/order-submit/order-submit?cart_id_list=" + true,
    })
  },

  noticelongtap:function(){
    return
  },

  isEditNum:function(e){
    var index = 0;
    if (e.currentTarget.dataset.index){
      index = e.currentTarget.dataset.index;
    }
    else{
      if (e.currentTarget.dataset.index==0)
      {
        index = e.currentTarget.dataset.index;
      }
      else{
        index = e.detail.index;
      }
      
    }

    var quantity = this.data.goodsList.list[parseInt(index)].quantity;
    quantity = parseInt(quantity);
    var editnum = this.data.editNum;
    this.setData({
      editNum:!editnum,
      index:index,
      quantity: quantity,
    })
  },

// 判断购物车中是否有商品
  carRequest: function (openid = app.globalData.openId) {
    wx.request({
      url: app.globalData.address + '/api/cart/isCartNull.html',
      data: {
        openid: openid,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function (res) {
        if (!res.data) {
          wx.showTabBarRedDot({
            index: 2,
          })
        }
        else {
          wx.hideTabBarRedDot({
            index: 2,
          })
        }
      }
    })
  }
})
