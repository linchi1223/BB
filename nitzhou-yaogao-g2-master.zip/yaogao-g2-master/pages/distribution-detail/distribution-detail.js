// pages/distribution-detail/distribution-detail.js
var app = getApp();
const pageable = require('../../utils/pageable.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    detailAll:[],
    pendingReview:[],
    completed:[],
    refused:[],
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    let e = null;
    var currentTab = options.currentTab ? options.currentTab : that.data.currentTab;
    that.setData({
      currentTab: options.currentTab ? options.currentTab : -1,
    });
    if (currentTab == 0) {
      that.detailAll(e);
    }
    switch (currentTab) {
      case '1':
        that.pendingReview(e);
        break;
      case '2':
        that.completed(e);
        break;
      case '3':
        that.refused(e);
        break;
      default:
        break;
    };

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          clientHeight: res.windowHeight
        });
      }
    });
  },
// 滑动切换
  swiperTab:function(e){
    var that = this;
    var params = null

    var currentTab = e.detail.current ? e.detail.current : 0;
    that.setData({
      currentTab: e.detail.current,
    }, () => {
      switch (currentTab) {
        case 0:
          that.detailAll(params);
          break;
        case 1:
          that.pendingReview(params);
          break;
        case 2:
          that.completed(params);
          break;
        case 3:
          that.refused(params);
          break;
        default:
          break;
      };
    });
  },
  // 点击切换
  clickTab: function (e) {
    if (e === null) {
      return;
    }
    var that = this;
    if (this.data.currentTab === e.currentTarget.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.currentTarget.dataset.current
      })
   }  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  // 请求后台数据(全部)
  detailAll: function (e) {
    var that = this;
    that.clickTab(e);
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/list.html",
      data: {
        openid: app.globalData.openId,
        searchProperty: 'type',
        searchValue: 'sub'
      },
      success: function (res) {
       
        that.setData({
          detailAll: res.data.data.content
        })
      }
    })
  },
  // 请求后台数据(待审核)
  pendingReview:function(e){
    var that = this;
    that.clickTab(e);
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/list.html",
      data: {
        openid: app.globalData.openId,
        searchProperty: 'status',
        searchValue: 'pendingReview'
      },
      success: function (res) {

        that.setData({
          pendingReview: res.data.data.content
        })
      }
    })
  },
  // 请求后台数据(已完成)
  completed:function(e){
    var that = this;
    that.clickTab(e);
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/list.html",
      data: {
        openid: app.globalData.openId,
        searchProperty: 'status',
        searchValue: 'completed'
      },
      success: function (res) {

        that.setData({
          completed: res.data.data.content
        })
      }
    })
  },
// 请求后台数据(已拒绝)
  refused:function(e){
    var that = this;
    that.clickTab(e);
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/list.html",
      data: {
        openid: app.globalData.openId,
        searchProperty: 'status',
        searchValue: 'refused'
      },
      success: function (res) {

        that.setData({
          refused: res.data.data.content
        })
      }
    })
  }


})