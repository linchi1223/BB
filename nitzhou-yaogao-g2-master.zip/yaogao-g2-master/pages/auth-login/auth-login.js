// pages/auth-login/auth-login.js

const app = getApp()
var a = 1;

Page({
  data: {
    params: {}
  },
  onLoad: function (options) {
    const params = JSON.parse(options.params)

    if (params) {
      this.setData({
        params
      })
    }
  },
  getUserInfo: function (e) {
    var that = this;
    const userInfo = e.detail.userInfo
    if (userInfo) {
      app.globalData.userInfo = userInfo;

      if (app.globalData.openId) {
 
        that.setUserInforReq(userInfo,that)
      }
      else{
        // wx.showToast({
        //   title: '请稍等一下',
        //   icon: 'none',
        // })
      }
    }
    else{
      wx.showToast({
        title: '信息为空',
        icon:'none',
      })
    }
  },

  setUserInforReq: function (userInfo,that){
    var params = that.data.params;
    wx.request({
      url: `${app.globalData.address}/api/wechat/setUserInfo.html`,
      data: {
        openid: app.globalData.openId,
        userInfo: userInfo
      },
      success: (res) => {
        if (res.data.msg === "success") {
          if (params.goodId) {
            wx.reLaunch({
              url: `/pages/index/index?goodId=${params.goodId}`
            })
          } else {
            wx.reLaunch({
              url: '/pages/index/index'
            })
          }
        } else {
          wx.showToast({
            title: '出错了',
            icon: 'none'
          })
        }
      }
    })
  }

})