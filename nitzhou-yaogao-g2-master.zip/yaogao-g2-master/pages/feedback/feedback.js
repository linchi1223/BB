// pages/feedback/feedback.js

const app = getApp()
Page({
  data: {
    otherFlag: true,
    otherFlag1: true
  },
  inputChange: function(e) {
    const name = e.target.dataset.name;
    const value = e.detail.value;

    if (value !== '') {
      this.setData({
        otherFlag: false
      })
    } else {
      this.setData({
        otherFlag: true
      })
    }
  },
  inputChange1: function(e) {
    const name = e.target.dataset.name;
    const value = e.detail.value;

    if (value !== '') {
      this.setData({
        otherFlag1: false
      })
    } else {
      this.setData({
        otherFlag1: true
      })
    }
  },
  feedbackbtn: function() {
    if (!this.data.content) {
      wx.showToast({
        title: '提交失败',
        icon: "none"
      })
      return
    }

    wx.request({
      url: `${app.globalData.address}/api/feedBack//save.html`,
      data: {
        content: this.data.content,
        mail: this.data.mail ? this.data.mail : "",
        otherInfo: this.data.otherInfo ? this.data.otherInfo : "",
        openid: app.globalData.openId
      },
      success: (res) => {
        if (res.data.msg == "success") {
          wx.showToast({
            title: '提交成功',
          })
          setTimeout(function() {
            wx.switchTab({
              url: '/pages/me/me',
            })
          }, 1000)
        }
      }
    })
  },
  suggest: function(e) {
    this.setData({
      content: e.detail.value
    })
  },
  email: function(e) {
    this.setData({
      mail: e.detail.value
    })
  },
  phone: function(e) {
    this.setData({
      otherInfo: e.detail.value
    })
  }
})