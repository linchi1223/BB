const WxParse = require('../../wxParse/wxParse.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  
  data: {
    active:0,
    list:[1,2,3,4,5,4,5,5,5,5],
    collect:true,
    playing:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id;
    this.setData({
      id:id,
    })
    this.getVideo(id);
  },

  selectActive:function(e){
    var id = e.currentTarget.dataset.id;
    id = parseInt(id);
    if(this.data.active ==id)
    {
      return
    }
    else{
      this.setData({
        active: id
      })
    }
  },
  getVideo:function(id){
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/video/view.html',
      data: {
        openid: app.globalData.openId,
        id: id,
      },
      success: function (res) {
        var data = res.data;
        if (data.code == 0) {
          that.setData({
            video: data.data.url,
          })
          wx.setNavigationBarTitle({
            title: data.data.name,
            success:(res)=>{

            },
            fail:(err)=>{
              console.log(err);
            },
          })
          var content = data.data.content;
          if (content) {
            WxParse.wxParse("detail", "html", content, that);
          }
        }
      }
    })
  },

  saveFile:function(){
    var that = this;
    wx.getSetting({
      success:(res)=>{
        if (res.authSetting['scope.writePhotosAlbum'])
        {
          wx.showModal({
            title: '文件',
            content: '是否保存该视频文件',
            success:function(res){
              if(res.confirm){
                that.downFile();
              }
            }
          })
        }
        else{
          that.downFile();
        }
      }
    })
   
  },

  downFile:function(){
    wx.downloadFile({
      url: this.data.video,
      success:function(res){
        if(res.statusCode==200)
        {
          wx.saveVideoToPhotosAlbum({
            filePath: res.tempFilePath,
            success:function(res)
            {
              console.log(res);
            },
            fail: function (res) {
              console.log('fail');
            },
            complete: function (res) {
              console.log('complete');
            }
          })
        }
      },
      fail:function(){
        console.log('fail');
      }
    })
  },

  collectTap:function(){
    this.setData({
      collect: !this.data.collect,
    })
  },

  play:function(){
    this.setData({
      playing:!this.data.playing,
    })
  }

})