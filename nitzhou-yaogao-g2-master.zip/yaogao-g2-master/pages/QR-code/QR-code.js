const app = getApp();
Page({
  data:{
    src:'',
  },
  onLoad:function(options){
    this.getAccesscode()
  },
  getAccesscode:function(){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/distributionBrokerage/token.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        const accessToken=res.data.msg;
        if(res.data.code==0)
        {
          that.setData({
            src:res.data.msg
          })
        }
      }
    })
  },

})