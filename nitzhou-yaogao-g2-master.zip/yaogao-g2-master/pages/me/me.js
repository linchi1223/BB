//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    orderNumber:{},
    motto: 'Hello World',
    userInfo: {},
    detail:[],
    hasUserInfo: false,
    myClassContent:'',
    canIUse: wx.canIUse('button.open-type.getUserInfo')

  },
  onLoad: function () {
    this.getBackground();

    // this.orderNumberRequest();
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    };
  },
  onShow:function(){
    this.orderNumberRequest();
    this.detailTap();
    this.getMyClass();
  },

  getUserInfo: function (e) {
    var that = this;
    const userInfo = e.detail.userInfo;
    if(userInfo)
    {
      app.globalData.userInfo = e.detail.userInfo
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      }, that.setUserInfo(userInfo));
      
    }
  }
  ,
  //编辑地址
  selectAddress: function () {
    wx.navigateTo({
      url: '/pages/address-addministration/address-addministration'
    })
  },

  // 设置用户的数据
  setUserInfo: function (userInfo){
    wx.request({
      url: app.globalData.address +'/api/wechat/setUserInfo.html',
      data:{
        userInfo: userInfo,
        openid:app.globalData.openId,
      },
      success:function(res){
      }
    })
  },
  // 个人中心背景图
  getBackground:function(){
    var that=this
    wx.request({
      url: app.globalData.address + '/api/article/background.html',
      data:{
        openid: app.globalData.openId,
      },
      success:function(res){
        that.setData({
          personal:res.data.data
        })
      }
    })
  },
  fenxiao:function(){
    // console.log(app.globalData.inviteCode);
    var that=this;
    if (app.globalData.inviteCode ==null) {
      wx.showModal({
        title: '申请成为分销商',
        content: '是否申请？',
        success: function (res) {
          if (res.confirm) {
            wx.request({
              url: app.globalData.address + '/api/distributionBrokerage/save.html',
              data: {
                openid: app.globalData.openId,
              },
              success: (res) => {
                if (res.data.code === 0) {
                  wx.showToast({
                    title: '申请成功',
                  })
                  wx.navigateTo({
                    url: '/pages/distribution-center/distribution-center',
                  })
                  app.globalData.inviteCode = res.data.msg;
                  // console.log(app.globalData.inviteCode);
                }
              }
            })
          } else if (res.cancel) {
          }
        }
      })
    }else{
      wx.navigateTo({
        url: '/pages/distribution-center/distribution-center',
      })
    }
  },
  

  // 请求后台获取菜单
  detailTap: function () {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/functions/isShow.html',
      data: {
        openid: app.globalData.openId,
      },
      success: function (res) {
        that.setData({
          detail: res.data.data
        })
      }
    })
  },

  // 我的等级
  getMyClass: function () {
    const that = this;
    wx.request({
      url: app.globalData.address + '/api/member/rank.html',
      data: {
        openid: app.globalData.openId,
      },
      success: function (res) {
        if (res.data.rank) {
          that.setData({
            myClassContent: res.data.rank,
          })
        }
      }
    })
  },

  orderNumberRequest:function(){
    wx.request({
      url: app.globalData.address+'/api/order/subscript.html',
      data:{
        openid:app.globalData.openId,
      },
      success: (res)=>{
        this.setData({
          orderNumber: res.data,
        })
      },
    })
  }
})
