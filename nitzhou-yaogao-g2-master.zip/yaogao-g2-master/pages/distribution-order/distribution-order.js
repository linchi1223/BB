// pages/distribution-order/distribution-order.js
var app = getApp();
const pageable = require('../../utils/pageable.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    status: '',
    currentTab: 0,
    // hidden: true,
    showItem:[],
    showItem2: [],
    showItem3: [],
    showItem4: [],
    src1: '/img/home/1.png',
    src2: '/img/home/2.png',
    orderAll: [],
    pendingPayment: [],
    pendingShipment: [],
    completed: [],
    orderDetail: {},
    clickItemId:0,
    clickItemId2: 0,
    clickItemId3: 0,
    clickItemId4: 0,
    
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;

    let e = null;
    var currentTab = options.currentTab ? options.currentTab : that.data.currentTab;
    that.setData({
      currentTab: options.currentTab ? options.currentTab : -1,
    });
    if (currentTab == 0) {
      that.orderAll(e);
    }

    switch (currentTab) {
      case '1':
        that.pendingPayment(e);
        break;
      case '2':
        that.pendingShipment(e);
        break;
      case '3':
        that.completed(e);
        break;
      default:
        break;
    };

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          clientHeight: res.windowHeight
        });
      }
    });
    // this.orderAll(),
    // this.pendingPayment();
    // this.pendingShipment();
    // this.completed();
    // this.orderDetail();

  },
  //滑动切换
  swiperTab: function(e) {
    var that = this;
    var params = null

    var currentTab = e.detail.current ? e.detail.current : 0;
    that.setData({
      currentTab: e.detail.current,
    }, () => {
      switch (currentTab) {
        case 0:
          that.orderAll(params);
          break;
        case 1:
          that.pendingPayment(params);
          break;
        case 2:
          that.pendingShipment(params);
          break;
        case 3:
          that.completed(params);
          break;
        default:
          break;
      };
    });

  },

  //点击切换
  clickTab: function(e) {
    if (e === null) {
      return;
    }

    var that = this;

    if (this.data.currentTab === e.currentTarget.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.currentTarget.dataset.current
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  hiddenBtn: function(e) {
    let index = e.currentTarget.dataset.index;
    var orderSn = e.currentTarget.dataset.ordersn;
    var that = this;
    var showItem = that.data.showItem;
    showItem[index] = !showItem[index];
    that.setData({
      showItem: showItem
    });   

  this.orderDetail(orderSn); 
},
  hiddenBtn2: function (e) {
    let index = e.currentTarget.dataset.index;
    var orderSn = e.currentTarget.dataset.ordersn;
    var that = this;
    var showItem2 = that.data.showItem2;
    showItem2[index] = !showItem2[index];
    that.setData({
      showItem2: showItem2
    });

    this.orderDetail(orderSn);
  },
  hiddenBtn3: function (e) {
    let index = e.currentTarget.dataset.index;
    var orderSn = e.currentTarget.dataset.ordersn;
    var that = this;
    var showItem3 = that.data.showItem3;
    showItem3[index] = !showItem3[index];
    that.setData({
      showItem3: showItem3
    });

    this.orderDetail(orderSn);
  },
  hiddenBtn4: function (e) {
    let index = e.currentTarget.dataset.index;
    var orderSn = e.currentTarget.dataset.ordersn;
    var that = this;
    var showItem4 = that.data.showItem4;
    showItem4[index] = !showItem4[index];
    that.setData({
      showItem4: showItem4
    });

    this.orderDetail(orderSn);
  },
  // hiddenBtn2: function (e) {
  //   let index = e.currentTarget.dataset.index;
  //   var orderSn = e.currentTarget.dataset.ordersn;
  //   var that = this;
  //   var arrayItem = this.data.pendingPayment;
  //   var hidden = that.data.hidden;
  //   that.setData({
  //     clickItemId2: arrayItem[index].orderId
  //   });
  //   that.setData({
  //     hidden: !that.data.hidden
  //   });

  //   this.orderDetail(orderSn);
  // },

// 请求后台数据(全部)
orderAll: function(e) {
  var that = this;
  that.clickTab(e);
  wx.request({
    url: app.globalData.address + "/api/distributionBrokerage/list.html",
    data: {
      openid: app.globalData.openId,
      searchProperty: 'type',
      searchValue: 'add'
    },
    success: function(res) {
      let order = res.data.data.content;
      for (let i = 0; i < order.length; i++) {
        order[i].orderStatus = that.switchStatus(order[i].orderStatus)
      };
      // that.orderDetail(res.data.data.content);
      that.setData({
        orderAll: res.data.data.content
      })
    }
  })
},
// 请求后台数据(详情)
orderDetail: function(orderSn) {
  var that = this;
  wx.request({
    url: app.globalData.address + '/api/distributionBrokerage/view.html',
    data: {
      openid: app.globalData.openId,
      sn: orderSn,
    },
    success: function(res) {
      that.data.orderDetail[orderSn]=res.data.data
      that.setData({
        orderDetail: that.data.orderDetail
      })
      // console.log(res.data.data);
    }
    
  })
},
// 请求后台数据(待付款)
pendingPayment: function(e) {
  var that = this;
  that.clickTab(e);
  wx.request({
    url: app.globalData.address + "/api/distributionBrokerage/list.html",
    data: {
      openid: app.globalData.openId,
      searchProperty: 'orderStatus',
      searchValue: 'pendingPayment'
    },
    success: function(res) {
      let order = res.data.data.content;
      for (let i = 0; i < order.length; i++) {
        order[i].orderStatus = that.switchStatus(order[i].orderStatus)
      }
      that.setData({
        pendingPayment: res.data.data.content
      })
    }
  })
},
// 请求后台数据(已付款)
pendingShipment: function(e) {
  var that = this;
  that.clickTab(e);
  wx.request({
    url: app.globalData.address + "/api/distributionBrokerage/list.html",
    data: {
      openid: app.globalData.openId,
      searchProperty: 'orderStatus',
      searchValue: 'pendingShipment'
    },
    success: function(res) {
      let order = res.data.data.content;
      for (let i = 0; i < order.length; i++) {
        order[i].orderStatus = that.switchStatus(order[i].orderStatus)
      }
      that.setData({
        pendingShipment: res.data.data.content
      })
    }
  })
},
// 请求后台数据(已完成)
completed: function(e) {
  var that = this;
  that.clickTab(e);
  wx.request({
    url: app.globalData.address + "/api/distributionBrokerage/list.html",
    data: {
      openid: app.globalData.openId,
      searchProperty: 'orderStatus',
      searchValue: 'completed'
    },
    success: function(res) {
      let order = res.data.data.content;
      for (let i = 0; i < order.length; i++) {
        order[i].orderStatus = that.switchStatus(order[i].orderStatus)
      }
      that.setData({
        completed: res.data.data.content
      })
    }
  })
},
switchStatus: function(orderStatus) {
  let StatusStr = '';
  if (orderStatus === 'pendingPayment') {
    StatusStr = '待付款';
  } else if (orderStatus === 'pendingShipment') {
    StatusStr = '已付款'
  } else if (orderStatus === 'completed') {
    StatusStr = '已完成'
  }
  return StatusStr;

},
})