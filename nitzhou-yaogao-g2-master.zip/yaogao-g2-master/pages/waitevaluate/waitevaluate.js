// pages/orderDetail/orderDetail.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: '',
    hasEvaluate: false,
    refundtext: "退款",
  },

  //立即评论
  evaluate: function () {
    const that = this;
    var sn = "";

    var orderItems = [];
    sn = that.data.orderId;
    orderItems = that.data.order.orderItems;
    if (orderItems) {
      if (orderItems.length > 1) {
        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'eva',
          }),
        })
      }
      if (orderItems.length == 1) {
        wx.navigateTo({
          url: '/pages/myevaluate/myevaluate?params=' + JSON.stringify({
            orderItemId: orderItems[0].id,
            productId: orderItems[0].productId,
            imgSrc: orderItems[0].thumbnail,
            name: orderItems[0].name,
          }),
        })
      }
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    that.setData({
      orderId: options.orderId,
      isReturn: (options.isReturn == 'false' ? false : true),
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.toDetail();
  },


  toDetail: function () {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/order/view.html',
      data: {
        openid: app.globalData.openId,
        sn: this.data.orderId,
      },
      success: function (res) {

        that.setData({
          order: res.data.data,
        }, that.setIsEvaluate(res.data.data))

      }
    })
  },

  setIsEvaluate: function (order) {
    var that = this;
    var orderItems = order.orderItems;
    var hasEvaluate = false;
    if (orderItems) {
      for (var i = 0; i < orderItems.length; i++) {
        if (!orderItems[i].review) {
          hasEvaluate = true;
        }
      }
      that.setData({
        hasEvaluate: hasEvaluate,
      })
    }
  },

  // 退款
  refund: function () {

    const that = this;
    var orderItems = [];
    var sn = "";
    sn = that.data.orderId;
    orderItems = that.data.order.orderItems;
    if (orderItems) {
      if (orderItems.length > 1) {
        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'refund',
          }),
        })
      }
      if (orderItems.length == 1) {
        that.refundRequset(orderItems[0].id, that);
      }
    }
  },

  //申请退款
  refundRequset: function (id, that) {
    wx.request({
      url: app.globalData.address + '/api/order/return.html',
      data: {
        orderItemId: id,
        openid: app.globalData.openId,
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.showToast({
            title: '申请退款成功',
            icon: 'success',
            mask: true,
            duration: 1500,
          })
          const pages = getCurrentPages();
          const beforepage = pages[pages.length - 2];

          setTimeout(() => {
            if (beforepage.__route__ === "pages/order/order") {
              beforepage.setData({
                pageNumber: 1,
                received: [],
              }, () => {
                beforepage.received(null);
              })

            }
            if (that.data.order.orderItems.length == 1) {
              that.setData({
                refundtext: '退款中',
              })
            }
          }, 700)
        }
      }
    })
  },

})