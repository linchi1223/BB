const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[1,2,3,4],
    bars:[],
    pageNumber:1,
    pageSize:10,
    videoList:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getBars();
    this.getVideoList();
  },

  goVideo:function(e){
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/video/video?id='+id,
    })
  },

  // 得到轮播图
  getBars:function(){
     var that = this;
    wx.request({
      url: app.globalData.address +'/api/video/ishome.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        var data = res.data;
        if(data.code==0)
        {
          that.setData({
            bars:data.data
          })
        }
      }
    })
  },

  // 得到视频列表

  getVideoList:function(){
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/video/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
      },
      success: function (res) {
        var data = res.data;
        if (data.code == 0) {
          var list = data.data.content;
          var videoList = that.data.videoList;
          if (that.data.pageNumber <= data.data.totalPages) {
            videoList = videoList.concat(list);
          }
          that.setData({
            videoList: videoList,
          })
        }
      }
    })
  }


})