// pages/address-addministration/address-addministration.js
const app = getApp()
const pageable = require('../../utils/pageable.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    delBtnWidth: 180, 
    showModalStatus: false,
    pageNumber: 0,
    pageSize: 5,
    options: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    //标题
    if (options.type) {
      that.setData({
        options: options.type
      })
    }

    wx.setNavigationBarTitle({
      title: "地址管理"
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this
    that.getaddress()
  },



  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

// 得到地址列表
  getaddress: function() {
    var that = this
    wx.request({
      url: app.globalData.address + "/api/receiver/list.html",
      data: {
        openid: app.globalData.openId,
        pageSize: 20,
        pageNumber: 1
      },
      success: function(res) {
        if (res.data) {
          const data = res.data
          that.setData({
            address: data.list
          })
        }

      }
    })
  },


  /**
   * 设置默认
   */
  setDefaultAddress: function(e) {
    var that = this
    var index = e.currentTarget.dataset.index;
    var is_default = !that.data.address[index].isDefault;
    wx.showToast({
      title: '正在设置...',
      icon: 'loading',
      mask: true,
      duration: 10000
    })
    wx.request({
      url: app.globalData.address + "/api/receiver/update.html",
      data: {
        consignee: that.data.address[index].consignee,
        phone: that.data.address[index].phone,
        address: that.data.address[index].address,
        zipCode: "311113",
        isDefault: is_default,
        openid: app.globalData.openId,
        areaName: that.data.address[index].areaName,
        id: that.data.address[index].id
      },
      success: function(res) {
        if (res.data) {
          that.getaddress()
          wx.setStorageSync("picker_address", that.data.address[index]);
          wx.hideToast();
          //判断是否从订单结算页面跳转进入
          if (that.data.options == 11) {
            // wx.navigateBack();
          }
        }
      }
    })
  },

  /**
   * 修改地址
   */
  goToupaddress: function(e) {
    const addressId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/upaddress/upaddress?addressId=${addressId}`
    })
  },

  /**
   * 删除
   */
  deleteaddress: function(e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确认删除该地址吗?',
      success:function(res){
        if(res.confirm)
        {
          wx.request({
            url: app.globalData.address + "/api/receiver/delete.html",
            data: {
              openid: app.globalData.openId,
              id: e.currentTarget.dataset.id
            },
            success: function (res) {
              if (res.data) {
                that.getaddress()
              }
            }
          })
        }
      }
    })

  },

// 选择地址
  goToBack: function(e) {
    var index = e.currentTarget.dataset.index;
    var address = this.data.address;

    const pages = getCurrentPages();
    let beforepage = pages[pages.length - 2];
    if (beforepage.__route__ === "pages/order-submit/order-submit"){
      var option = beforepage.data.options;
      beforepage.setData({
        addressId: address[index].id,
      }, () => {
        beforepage.getOrderData(option);
        wx.navigateBack();
      })
      
      // if (option.cart_id_list)
      // {
      //   this.getExpressPrice(address[index])
      // }
      // if (option.goods_info)
      // {
      //   var productid = beforepage.data.productId;
      //   var quantity = beforepage.data.quantity;
      //   this.getExpressPrice(address[index],productid,quantity);
      // }
    }
    
  },


  // 获得运费的接口
  getExpressPrice(address ,productId = null, quantity = null) {
    wx.request({
      url: app.globalData.address +'/api/order/checkout3.html',
      data:{
        openid : app.globalData.openId,
        productId:productId,
        receiverId: address.id,
        quantity: quantity,
        exhibitionId:app.globalData.exhibitionId,
      },
      success:function(res){
        if(res.data.code==0)
        {
          var express_price = res.data.data.order.freight;
          var total_price = res.data.data.order.amount
          const pages = getCurrentPages();
          let beforepage = pages[pages.length - 2];
          if (beforepage.__route__ === "pages/order-submit/order-submit") {

            beforepage.setData({
              address: address.areaName + address.address,
              name: address.consignee,
              mobile: address.phone,
              addressId: address.id,
              express_price: express_price,
              total_price:total_price,
            }, wx.navigateBack())
          }
        }


      },
    })
  }
})