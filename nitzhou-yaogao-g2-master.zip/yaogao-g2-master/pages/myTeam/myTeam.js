
const app = getApp();
Page({
  data:{
    currentTab:0,
    scrollViewHeigh:672,
    oneMembers:[],
    twoMembers:[],
    threeMembers:[],
    member_1: 0,
    member_2: 0,
    member_3: 0,
    member:[0,1,2,4,5,7,7,8,9,3,4,5,10,90,3,4,5,3,6,7],
    // member:[0]
  },

  onLoad:function(options){
    var that = this;
    this.getMyTeamOne(this.data.currentTab);
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          scrollViewHeigh: res.windowHeight
        });
      }
    });
  },

  clickTab:function(e){
    var Tab = e.currentTarget.dataset.currenttab;
    var currentTab = this.data.currentTab
    if(Tab === currentTab)
    {
      return ;
    }
    else{
      this.setData({
        currentTab:Tab,
      })
    }
  },

  swiperTab:function(e){
    var currentTab = e.detail.current?e.detail.current:0;
    this.setData({
      currentTab:currentTab,
    }, this.getMyTeamOne(currentTab))
  },

  getMyTeamOne:function(currentTab){
    var that = this;
    wx.request({
      url: app.globalData.address+'/api/distributionBrokerage/findDescendant.html',
      data:{
        distance: currentTab+1,
        openid:app.globalData.openId,
      },
      success:function(res){
       if(res.data.code==0){
         if(currentTab==0){
           that.setData({
             member_1: res.data.data.member_1,
             member_2: res.data.data.member_2,
             member_3: res.data.data.member_3,
             oneMembers: res.data.data.members,
           })
         }
         if(currentTab==1){
           that.setData({
             member_1: res.data.data.member_1,
             member_2: res.data.data.member_2,
             member_3: res.data.data.member_3,
             twoMembers: res.data.data.members,
           })
         }
         if(currentTab==2){
           that.setData({
             member_1: res.data.data.member_1,
             member_2: res.data.data.member_2,
             member_3: res.data.data.member_3,
             threeMembers: res.data.data.members,
           })
         }
       }
      }
    })
  },
  
})