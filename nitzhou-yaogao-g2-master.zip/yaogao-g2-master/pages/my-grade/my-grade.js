// pages/my-grade/my-grade.js

const app = getApp()

Page({
  data: {

  },
  onShow: function () {
    wx.request({
      url: `${app.globalData.address}/api/pointLog/personalPoint.html`,
      data: {
        openid: app.globalData.openId
      },
      success: (res) => {
        this.setData({
          grade: res.data
        })
      }
    })
  },
  goToGradeDetail: function() {
    wx.navigateTo({
      url: `/pages/grade-detail/grade-detail?grade=${this.data.grade}`,
    })
  },
  goToorder: function() {
    wx.navigateTo({
      url: '/pages/order/order?currentTab=4',
    })
  }
})