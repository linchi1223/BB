Page({

  /**
   * 页面的初始数据
   */
  data: {
    classify:[
      { name: '居家'},
      { name: '居家' },
      { name: '居家' },
      { name: '居家' },
      { name: '居家' },
      { name: '居家' },
      { name: '居家' },
      { name: '居家' },
    ],
    current:0,
    image:[0,1,2,3],
    goods: [0, 1, 1, 3],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  selectCurrent:function(e){
    var current = this.data.current;
    if(e.currentTarget.dataset.current==current)
    {
      return
    }
    else{
      this.setData({
        current:e.currentTarget.dataset.current,
      })
    }
  }
 

})