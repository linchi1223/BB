
const app = getApp();
const WxParse = require('../../wxParse/wxParse.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nextrank:'',
    currentExperience:'',
    nextExpreience:'',
    content:'',
    icon1image:'',
    icon1name:'',
    icon2image:'',
    icon2name:'',
    icon3image:'',
    icon3name:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getMemberInfo();
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
// 获取经验值的进度圆环
  drawProgressBg:function(){
    var context = wx.createCanvasContext("circleProgressBg");
    var str="/img/circle.png"
    context.setLineWidth(8);
    context.setStrokeStyle("#484B4D");
    context.setLineCap('round');
    context.beginPath();
    context.arc(75,75,66,0,2*Math.PI,false)
    context.stroke();
    context.draw();
    
  },
  drawCircle:function(step){
    var context = wx.createCanvasContext("circleProgress");
 
    var gradient = context.createLinearGradient(130,65,65,130);
    gradient.addColorStop('0','#7E94B9');
    gradient.addColorStop('1', '#7E94B9');

    context.setLineWidth(6);

    context.setStrokeStyle(gradient);
    context.setLineCap('round');
    context.beginPath();
    context.arc(75,75,66,-Math.PI/2,step*Math.PI - Math.PI/2,false);
    context.stroke();
    context.draw();
  },


  goToMembersIntructions:function(){
    wx.navigateTo({
      url: '/pages/members-instructions/members-instructions',
    })
  },
  
  getMemberInfo:function(){
    const that = this;
    wx.request({
      url: app.globalData.address +'/api/member/center.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        // console.log(res);
        var content = res.data.content;
        var currentExp = parseFloat(res.data.exp);
        var nextExp = parseFloat(res.data.nextexp);
        var step;
        that.setData({
          nextrank: res.data.nextrank,
          currentExperience: res.data.exp,
          nextExpreience: res.data.nextexp,
          content: content,
          icon1image: res.data.icon1image,
          icon1name: res.data.icon1name,
          icon2image: res.data.icon2image,
          icon2name: res.data.icon2name,
          icon3image: res.data.icon3image,
          icon3name: res.data.icon3name,
        });
        step = nextExp>0?((currentExp*2)/nextExp):2;
        if(step<=0.001)
        {
          step = 0.001;
        }
        // that.drawProgressBg();
        that.drawCircle(step);
        if(content){
          WxParse.wxParse("detail","html",content,that);
        }

      }
    })
  },
})