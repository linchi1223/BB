Page({
  data:{
    list:[
      { img:'/img/common/video.png',name:'12'},
      { img: '/img/common/video.png', name: '34' },
      { img: '/img/common/video.png', name: '56' },
      { img: '/img/common/video.png', name: '78' },
      { img: '/img/common/video.png', name: '13' },
      { img: '/img/common/video.png', name: '25' },
      { img: '/img/common/video.png', name: '37' },
      { img: '/img/common/video.png', name: '13' },
      { img: '/img/common/video.png', name: '25' },
      { img: '/img/common/video.png', name: '37' }
      ]
  },
  onLoad:function(){

  },
  onShow:function(){

  },
  goToVideo:function(){
    wx.navigateTo({
      url: '/pages/video/video',
    })
  }
})