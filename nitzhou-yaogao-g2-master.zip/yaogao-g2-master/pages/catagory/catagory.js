// pages/resource/resource.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: [],//导航栏
    activeCategoryId: 0, //导航栏标识
    goods: [], //商品信息
    scrollTop: "0",
    hasNoCoupons: true,
    pagey: 1
  },
  /**
    * 导航栏功能
    */
  tabClick: function (e) {
    this.setData({
      activeCategoryId: e.currentTarget.id  //导航栏的一个标识
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //标题
    this.setData({
      activeCategoryId: options.id  //导航栏的一个标识
    });
    wx.setNavigationBarTitle({
      title: "商品列表"
    })
    var that = this
    var categories = [{ id: 0, name: "热销" }, { id: 1, name: "新品" }, { id: 2, name: "综合" }, { id: 3, name: "价格" }, { id: 4, name: "销量" }];
    that.setData({
      categories: categories,
    });
    that.getgoods();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var goods = this.data.goods
    var pagey = this.data.pagey + 1
    var that = this
    wx.request({
      url: app.globalData.address+'/api/goods/list.html',
      data: {
        openid:app.globalData.openId,
        pageSize: 6,
        pageNumber: pagey,
      },
      success: function (res) {
        if (pagey <= res.data.data.totalPages) {
          for (var i = 0; i < res.data.data.content.length; i++) {
            goods.push(res.data.data.content[i]);
          }
        }
        else {
          that.setData({
            loadingMoreHidden: false
          })
        }
        that.setData({
          goods: goods,
          pagey: pagey
        })
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  getgoods: function (e) {
    var that = this
    var goods = []
    wx.request({
      url: 'https://tooth.vverp.com/api/goods/list.html',
      data: {
        openid:app.globalData.openId,
        pageSize: 6
      },
      success: function (res) {
        for (var i = 0; i < res.data.data.content.length; i++) {
          goods.push(res.data.data.content[i]);
        }
        that.setData({
          goods: goods
        })
      }
    })
  },
})