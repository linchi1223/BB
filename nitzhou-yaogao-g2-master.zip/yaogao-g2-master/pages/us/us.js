// pages/us/us.js
const WxParse = require('../../wxParse/wxParse.js');
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.aboutUs();
  },


  aboutUs:function(){
    var that=this;
    wx.request({
      url: app.globalData.address  + '/api/article/about.html',
      data:{
        openid: app.globalData.openId,
      },
      success:function(res){
        var aboutUs = res.data.data.content;
        that.setData({
          aboutUs:res.data.data
        });
        if (aboutUs){
          WxParse.wxParse("detail", "html", aboutUs, that);
        }
        
      }
    })
  }
})