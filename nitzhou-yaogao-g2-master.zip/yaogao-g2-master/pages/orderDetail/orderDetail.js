// pages/orderDetail/orderDetail.js
var app = getApp()
const payment = require('../../utils/payment.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paymentPop: false,
    orderId: '',
    refundtext: '退款',
  },

  //取消订单
  canelOrder: function (e) {
    wx.showModal({
      title: '提示',
      content: '是否取消订单',
      success: function (res) {
        if (res.confirm) {

          wx.request({
            url: app.globalData.address + '/api/order/cancel.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {

              if (res.data.code === 0) {
                wx.showToast({
                  title: '订单取消成功',
                  icon: 'success',
                  duration: 1500,
                  mask: true,
                })

                setTimeout(() => {
                  const pages = getCurrentPages();
                  const beforepage = pages[pages.length - 2];

                  if (beforepage.__route__ === "pages/order/order") {
                    beforepage.setData({
                      pageNumber: 1,
                      orderAll: [],
                      pendingPayment: [],
                    }, () => {
                      beforepage.orderAll(null);
                      beforepage.pendingPayment(null)
                    })

                  }
                  wx.navigateBack();
                }, 1000)

              }
              if (res.data.code === 1) {
                wx.showToast({
                  title: '订单已过期',
                  icon: "none",
                  duration: 1000,
                })
              }

            }
          });
        } else if (res.cancel) {
        }
      }
    })
  },
  // 查看物流
  logistics: function (e) {
    wx.navigateTo({
      url: "/pages/logistics-info/logistics-info?orderId=" + e.currentTarget.dataset.sn,
    })
  },

  // 取消支付后跳转到订单页面
  cancelToOrder: function () {
    wx.redirectTo({
      url: '/pages/order/order?currentTab=0'
    })
  },

  // 去支付
  goToPay: function (e) {
    var page = this;
    var sn = e.currentTarget.dataset.sn;
    var paymethod = page.data.order.payMethod;
    var totalPrice = page.data.order.amount;
    if (paymethod == '余额支付') {
      console.log(paymethod)
      page.setData({
        paymentPop: true,
        sn: sn,
        totalPrice: totalPrice,
      })
    } else {
      this.setData({
        sn: sn,
        totalPrice: totalPrice,
      }, () => {
        this.payment();
      })
    }
  },

  payment: function () {
    var page = this;
    var sn = page.data.sn;
    var totalPrice = page.data.totalPrice;
    wx.request({
      url: app.globalData.address + '/api/order/create3.html',
      data: {
        openid: app.globalData.openId,
        sn: sn,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function (res) {
        if (res.data.code === 0) {
          page.setData({
            paymentPop: false,
          })
          page.orderPay(page, res, totalPrice);
        };
        if (res.data.code === 1) {
          wx.showToast({
            title: res.data.msg,
            icon: "none",
            duration: 1000,
          })
        }

      }

    })


  },

  // 支付接口
  orderPay: function (page, res, totalPrice) {
    let data = res.data.data;

    if (data.method === "wx") {
      payment.initPay(data.wx, () => {
        wx.redirectTo({
          url: `/pages/pay-success/pay-success?price=${totalPrice}&&id=${res.data.data.orderId}`
        })
      }, (res) => {
        if (res.errMsg === "requestPayment:fail cancel") {
          wx.showToast({
            title: '支付被取消',
            icon: 'none',
            duration: 650,
          });
          setTimeout(() => {
            page.cancelToOrder();
          }, 650)
        }

      })
    }
    else if (data.method === "balance") {
      if (data.result === "success") {
        wx.showToast({
          title: '余额支付成功',
          icon: "success",
          duration: 1500,
          success: function () {
            setTimeout(() => {
              wx.redirectTo({
                url: `/pages/pay-success/pay-success?price=${totalPrice}&&id=${res.data.data.orderId}`
              })
            }, 1000)
          }
        })
      }
      else {
        wx.showToast({
          title: "余额不足",
          icon: 'none',
          duration: 1500,
        });
      }
    }
  },

  // 确认收货
  confirmReceipt: function (e) {
    var that = this;

    wx.showModal({
      title: '提示',
      content: '是否确认收货',
      success: function (res) {
        if (res.confirm) {

          wx.request({
            url: app.globalData.address + '/api/order/receive.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {

              if (res.data.msg === "success") {
                wx.showToast({
                  title: '收货成功',
                  // complete: this.refresh,
                  // duration: 600,

                })

              }

            }
          });
        } else if (res.cancel) {

        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      orderId: options.orderId,
      isReturn: options.isReturn == 'false' ? false : true,
    }, that.toDetail(options.orderId));
  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // this.toDetail();
  },



  toDetail: function (orderId) {
    var that = this;

    wx.request({
      url: app.globalData.address + '/api/order/view.html',
      data: {
        openid: app.globalData.openId,
        sn: orderId || that.data.orderId,
      },
      success: function (res) {

        that.setData({
          order: res.data.data,
        })
      }
    })
  },

  confirmOrder: function () {
    wx.navigateTo({
      url: '/pages/order-submit/order-submit',
    })
  },

  evaluate: function () {
    const that = this;
    var sn = "";

    var orderItems = [];
    sn = that.data.orderId;
    orderItems = that.data.order.orderItems;
    if (orderItems) {
      if (orderItems.length > 1) {
        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'eva',
          }),
        })
      }
      if (orderItems.length == 1) {
        wx.navigateTo({
          url: '/pages/myevaluate/myevaluate?params=' + JSON.stringify({
            orderItemId: orderItems[0].id,
            productId: orderItems[0].productId,
            imgSrc: orderItems[0].thumbnail,
            name: orderItems[0].name,
          }),
        })
      }
    }

  },


  // 退款
  refund: function () {

    const that = this;
    var orderItems = [];
    var sn = "";
    sn = that.data.orderId;
    orderItems = that.data.order.orderItems;
    if (orderItems) {
      if (orderItems.length > 1) {
        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'refund',
          }),
        })
      }
      if (orderItems.length == 1) {
        that.refundRequset(orderItems[0].id, that);
      }
    }
  },
  //申请退款
  refundRequset: function (id, that) {
    wx.request({
      url: app.globalData.address + '/api/order/return.html',
      data: {
        orderItemId: id,
        openid: app.globalData.openId,
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.showToast({
            title: '申请退款成功',
            icon: 'success',
            mask: true,
            duration: 1500,
          })
          const pages = getCurrentPages();
          const beforepage = pages[pages.length - 2];

          setTimeout(() => {
            if (beforepage.__route__ === "pages/order/order") {
              beforepage.setData({
                pageNumber: 1,
                orderAll: [],
              }, () => {
                beforepage.orderAll(null);
              })

            }
            if (that.data.order.orderItems.length == 1) {
              that.setData({
                refundtext: '退款中',
              })
            }
          }, 700)
        }
      }
    })
  },
  // 取消支付
  payError: function () {
    this.setData({
      paymentPop: false,
    }, () => {
      wx.showToast({
        title: '支付取消',
        icon: 'none',
        duration: 1000,
      })
    })
  },
  noticelongtap: function () {
    return
  }
})