// pages/choose-coupon/choose-coupon.js

const app = getApp()
const pageable = require('../../utils/pageable.js')

Page({
  data: {
    pageNumber: 0,
    pageSize: 10,
    selectedCoupons: [],
    btnText: "不使用优惠券"
  },
  onLoad: function (options) {
    const params = JSON.parse(options.params);
    var price = params.price;
    var allQuantity = params.allQuantity;
    var code = params.code;
    this.setData({
      price,
      allQuantity,
      code,
    }, this.getPageItem(price,allQuantity,code))
  },

  onReachBottom: function () {
    // this.getPageItem()
  },

  // getPageItem: function () {
  //   const url = `${app.globalData.address}/api/coupon/personalcoupon.html`
  //   const params = {
  //     openid: app.globalData.openId,
  //     statu:'unused',
  //     price: this.data.price
  //   }

  //   pageable.getPage(this, url, params, 'list')
  // },


 // 获得满足条件的优惠券列表
  getPageItem: function (price, allQuantity,code){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/coupon/available.html',
      data:{
        code:code,
        price: price,
        quantity: allQuantity,
        openid:app.globalData.openId,
      },
      success:function(res){
        that.setData({
          pageList:res.data.data,
        })
      }
    })
  },

  clickCoupon: function (e) {
    const detail = e.detail
    let selectedCoupons = this.data.selectedCoupons

    if (detail.selected) {
      let index = selectedCoupons.findIndex((value) => {
      return value.id === detail.id
      })

      if (index > -1) {
        selectedCoupons.splice(index, 1)
      }
    } else {
      selectedCoupons.push(detail)
    }

    let btnText = ''
    if (selectedCoupons.length === 0) {
      btnText = '不使用优惠券'
    } else if (selectedCoupons.length === 1) {
      btnText = '使用该优惠券'
    } else {
      btnText = '只能使用一张优惠券'
    }

    this.setData({
      selectedCoupons,
      btnText
    })
  },
  
  clickBtn: function () {
    var that = this;
    const selectedCoupons = this.data.selectedCoupons
    var beforePrice = 0;

    if (selectedCoupons.length > 1) {
      return
    }

    const pages = getCurrentPages()
    const beforePage = pages[pages.length - 2]

    if (beforePage.__route__ === 'pages/order-submit/order-submit') {

      beforePrice = beforePage.data.orderPrice;
      var expressPrice = beforePage.data.express_price;
      if (selectedCoupons.length === 1) {

        var price = selectedCoupons[0].priceExpression ? selectedCoupons[0].priceExpression : 0;
        beforePage.setData({
          coupon: selectedCoupons[0],
          couponName: selectedCoupons[0].name,
          // total_price: (beforePrice - price) < 0 ? expressPrice : (beforePrice - price+expressPrice),
          subPrice: price,
          check: price != '0' ? 'price' : 'illegal',
        }, () => {
          beforePage.getOrderData(beforePage.data.options,that.callBack);
        })
      } else if (selectedCoupons.length === 0) {
        beforePage.setData({
          couponName: "优惠券",
          coupon: null,
          // total_price: parseFloat(beforePrice+expressPrice),
          check: null,
          subPrice: 0,
        }, () => {
          beforePage.getOrderData(beforePage.data.options,that.callBack);
        })
      }
    }
  },

  callBack:function(){
    console.log("callback")
    wx.navigateBack();
  }
})