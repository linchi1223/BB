// pages/classify/classify.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    category: [],
    curIndex: 0,
    isScroll: false,
    toView: "",
    detail: [],
    categoryId: 0,
    kindIndex: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    //标题
    wx.setNavigationBarTitle({
      title: "分类"
    })
    that.getdetail()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  

  /**
   * 获取商品列表
   */
  getGoodsList: function (categoryId) {
    var that = this;
    wx.request({
      url: app.globalData.address+'/api/goods/list.html',
      data: {
        openid: app.globalData.openId,
        categoryId: categoryId,
        exhibitionId:app.globalData.exhibitionId,
      },
      success(res) {
  
        that.setData({
          detail: res.data.data.content
        })
      }
    });
  },

  /**
   * 获取导航栏
   */
  getdetail() {
    var that = this;
    var name = ""
    wx.request({
      url: app.globalData.address+'/api/productCategory/list.html',
      success(res) {

        that.setData({
          //kindList: res.data.data
          category: res.data.data
        })
        that.setData({
          toView: that.data.category[0].name,
        })
        that.getGoodsList(res.data.data[0].id)
      }
    });
  },

  switchTab(e) {
    var that = this;

    that.setData({
      kindIndex: e.target.dataset.index
    })
 

    const self = this;
    this.setData({
      isScroll: true
    })
    self.getGoodsList(e.target.dataset.cid)
    setTimeout(function () {
      self.setData({
        toView: self.data.category[e.target.dataset.index].name,
        curIndex: e.target.dataset.index
      })
    }, 0)
    setTimeout(function () {
      self.setData({
        isScroll: false
      })
    }, 1)

  },
  /**
  * 搜索框区域功能
  */
  toSearch: function () {
    wx.navigateTo({
      url: "/pages/home-search/home-search"
    })
  },
  //  跳转到详情页面
  toDetailsTap: function (e) {
    wx.navigateTo({
      url: "/pages/goods-new/goods-new?id=" + e.currentTarget.dataset.cid
    })
  }
})