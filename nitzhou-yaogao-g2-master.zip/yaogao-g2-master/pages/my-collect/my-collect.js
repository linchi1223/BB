// pages/my-collect/my-collect.js

const app = getApp()
const pageable = require('../../utils/pageable.js')

Page({
  data: {
    pageNumber: 0,
    pageSize: 10
  },
  onShow: function () {
    this.setData({
      pageNumber:0,
    })
    this.getPageItem()
  },
  onReachBottom: function () {
    this.getPageItem()
  },
  getPageItem: function () {
    const url = `${app.globalData.address}/api/goods/myCollectGoods.html`
    const params = {
      openid:app.globalData.openId,
    }
    pageable.getPage(this, url, params, 'goods',res =>{
    })
  }
})