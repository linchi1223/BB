// pages/userGuide/userGuide.js
var app = getApp();
const WxParse = require('../../wxParse/wxParse.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.toDetail();
  },

  

  toDetail: function () {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/article/guide.html',
      data: {
        openid: app.globalData.openId,
      },
      success: function (res) {
        var content = res.data.data.content;
        that.setData({
          userGuide: res.data.data
        })
        if(content)
        {
           WxParse.wxParse("detail", "html", content, that);
        }     
      }
    })
  }
})