Page({
  data:{
    currentIndex: 0,
    loading: false,
    order:[0, 1, 2, 3, 4]
  },
  onLoad:function(){

  },
  onShow:function(){

  },
  onHide:function(){

  },

  selectIndex:function(e){
    var index = e.currentTarget.dataset.index;
    this.setIndex(index);
  },

  changIndex:function(e){
    var index = e.detail.current;
    this.setIndex(index);
  },

  setIndex: function (index) {
    index = parseInt(index);
    this.setData({
      currentIndex: index,
    }, () => {
      // 请求后台数据。
    })
  },

})