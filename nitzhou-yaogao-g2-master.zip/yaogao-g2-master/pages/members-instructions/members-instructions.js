const app = getApp()
const pageable = require('../../utils/pageable.js');
const WxParse = require('../../wxParse/wxParse.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab:0,
   
    empiricValue:[],
    pageNumber: 0,
    pageSize: 10,
    powerContent:'',
    upGradeContent:'',
    myClassContent:'',
    rule1:'',
    rule2:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
    this.getMyClass();
  
  },
  /**
   * 页面上拉触底事件的处理函数
    */
  onReachBottom: function () {
    this.empiricList()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  selectTab:function(e){ 
    var current = e.currentTarget.dataset.current;
    var currentTab = this.data.currentTab;
   
    // this.swithCurrent(current);

    if (current == currentTab) {
      return
    }
    else {
      this.setData({
        currentTab: current,
      })
    }
  },

  swiperTab:function(e){
    var current = e.detail.current;
    var currentTab = this.data.currentTab;
    var currentstr = "" + current
    this.swithCurrent(currentstr);

    if(current == currentTab){
      return
    }
    else{
      this.setData({
        currentTab:current,
      })
    }
  },
//选择请求后台数据
swithCurrent:function(current){
  var that = this;
  switch(current){
    case "0": that.getMyClass();break;
    case "1": that.getHowUpgrade();break;
    case "2": that.getPower();break;
    case "3": that.empiricValue(); that.empiricList();break;
  }
},

// 我的经验值
// 当前经验值
empiricValue:function(){
var that=this;
wx.request({
  url: app.globalData.address + "/api/member/exp.html",
  data:{
    openid: app.globalData.openId,
  },
  success:function(res){
    that.setData({
      empiricValue:res.data
    })
  }
})
},

// 获得经验值详情
  empiricList:function(){
    const url = app.globalData.address + "/api/member/list.html";
    var params = {
      openid: app.globalData.openId,
    }
    pageable.getPage(this, url, params, 'content')
  },

  // 我的等级
  getMyClass:function(){
    const that = this;
    wx.request({
      url: app.globalData.address + '/api/member/rank.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        if(res.data.rank){
          that.setData({
            myClassContent: res.data.rank,
            rule1:res.data.rule1,
            rule2:res.data.rule2,
          }) 
        }
      }
    })
  },

  // 如何升级
  getHowUpgrade:function(){
    const that = this;
    wx.request({
      url: app.globalData.address + '/api/member/upgrade.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
        var content = res.data.data.content;
        if(res.data.code==0){
          // that.setData({
          //   upGradeContent: res.data.data.content,
          // })
         
          if(content){
            WxParse.wxParse("detail","html",content,that)
          }
        }
      }
    })
  },

  // 有什么权益
  getPower:function(){
    const that = this;
    wx.request({
      url: app.globalData.address + '/api/member/interest.html',
      data:{
        openid:app.globalData.openId,
      },
      success:function(res){
       if(res.data.code==0)
       {
         var content = res.data.data;
         if (res.data.code == 0) {
          //  that.setData({
          //    powerContent: res.data.data,
          //  });
           if (content) {
             WxParse.wxParse("detail", "html", content, that);
           }
         }
       }
      }
    })
  }
})