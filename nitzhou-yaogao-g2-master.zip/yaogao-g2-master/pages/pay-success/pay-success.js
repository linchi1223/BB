// pages/pay-success/pay-success.js
const app = getApp();
Page({
  data: {
    code:'',
  },
  onLoad: function (options) {
    this.setData({
      price: options.price,
      id:options.id,
    })
    this.getPickUpCode(options.id)
  },
 
  returnIndex: function () {
    wx.switchTab({
      url: '/pages/index/index'
    })
  },
  gotoOrder: function () {
    wx.navigateTo({
      url: '/pages/order/order?currentTab='+0,
    })
  },
  getPickUpCode:function(id){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/exhibition/pickUpCode.html',
      data:{
        id:id
      },
      success:function(res){
        if(res.data.code==0)
        {
          that.setData({
            code:res.data.data,
          })
        }
      }
    })
  }
})