// pages/orderDetail/orderDetail.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: '',
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    that.setData({
      orderId: options.orderId,
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.toDetail();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  toDetail: function () {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/order/view.html',
      data: {
        openid: app.globalData.openId,
        sn: this.data.orderId,
      },
      success: function (res) {

        that.setData({
          order: res.data.data,
        })
      }
    })
  },
  // 确认收货
  confirmReceipt: function (e) {
    var that = this;

    wx.showModal({
      title: '提示',
      content: '是否确认收货',
      success: function (res) {
        if (res.confirm) {

          wx.request({
            url: app.globalData.address + '/api/order/receive.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {
              if (res.data.msg === "success") {
                wx.showToast({
                  title: '收货成功',
                  // complete: this.refresh,
                  // duration: 600,
                  complete: () => {
                    const pages = getCurrentPages();
                    beforepage = pages[pages.length - 2];
                    if (beforepage.__route__ === "pages/order/order") {
                      beforepage.setData({
                        pageNumber: 1,
                        shipped: [],
                        orderAll: [],
                      }, () => {
                        beforepage.shipped(null);
                        beforepage.orderAll(null);
                      })
                    }
                  }

                })

              }

            }
          });
        } else if (res.cancel) {

        }
      }
    })
  },
  // 查看物流
  logistics: function (e) {
    wx.navigateTo({
      url: "/pages/logistics-info/logistics-info?orderId=" + e.currentTarget.dataset.sn,
    })
  },
})