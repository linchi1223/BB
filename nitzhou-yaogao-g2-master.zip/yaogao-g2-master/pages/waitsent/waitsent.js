// pages/orderDetail/orderDetail.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: '',

  },

  remind: function () {
    wx.showToast({
      title: '已提醒发货',
      icon: 'success',
      duration: 2000
    })
  },
  //取消订单
  canelOrder: function (e) {
    wx.showModal({
      title: '提示',
      content: '是否取消订单',
      success: function (res) {
        if (res.confirm) {

          wx.request({
            url: app.globalData.address + '/api/order/cancel.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {

              if (res.data.code === 0) {
                wx.showToast({
                  title: '订单取消成功',
                  duration: 1500,
                  icon: 'success',
                })
                setTimeout(() => {
                  const pages = getCurrentPages();
                  const beforepage = pages[pages.length - 2];

                  if (beforepage.__route__ === "pages/order/order") {
                    beforepage.setData({
                      pageNumber: 1,
                      order: [],
                    }, () => {
                      beforepage.pendingShipment(null);
                    })

                  }
                  wx.navigateBack();
                }, 1000)
              }

            }
          });
        } else if (res.cancel) {
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    that.setData({
      orderId: options.orderId,
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.toDetail();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  toDetail: function () {
    var that = this;
    wx.request({
      url: app.globalData.address + '/api/order/view.html',
      data: {
        openid: app.globalData.openId,
        sn: this.data.orderId,
      },
      success: function (res) {

        that.setData({
          order: res.data.data,
        })
      }
    })
  }
})