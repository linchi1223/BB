// pages/order/order.js

var app = getApp()
const payment = require('../../utils/payment.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paymentPop: false,
    status: '',
    currentTab: 0,

    orderAll: [],
    order: [],
    pendingPayment: [],
    // pendingShipment: [],
    shipped: [],
    received: [],
    kindIndex: 0,

    pageNumber: 1,
    pageSize: 10,
  },

  // 评价有礼
  evaluate: function (e) {
    const that = this;
    var order = e.currentTarget.dataset.from;
    var index = e.currentTarget.dataset.orderindex;
    var sn = "";
    var orderItems = [];
    if (order == "eva") {
      sn = that.data.received[index].sn;
      orderItems = that.data.received[index].orderItems
    }
    if (order == 'all') {
      sn = that.data.orderAll[index].sn;
      orderItems = that.data.orderAll[index].orderItems
    }
    if (orderItems) {
      if (orderItems.length > 1) {

        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'eva',
          }),
        })
      }
      if (orderItems.length == 1) {
        wx.navigateTo({
          url: '/pages/myevaluate/myevaluate?params=' + JSON.stringify({
            orderItemId: orderItems[0].id,
            productId: orderItems[0].productId,
            imgSrc: orderItems[0].thumbnail,
            name: orderItems[0].name,

          }),
        })
      }
    }

  },


  // 退款
  refund: function (e) {

    const that = this;
    var order = e.currentTarget.dataset.from;
    var index = e.currentTarget.dataset.orderindex;
    var orderItems = [];
    var sn = "";
    if (order === 'all') {
      sn = that.data.orderAll[index].sn;
      orderItems = that.data.orderAll[index].orderItems;
    }
    if (order === 'eva') {
      sn = that.data.received[index].sn;
      orderItems = that.data.received[index].orderItems;
    }
    if (orderItems) {
      if (orderItems.length > 1) {
        wx.navigateTo({
          url: '/pages/carOrderEvaluate/carOrderEvaluate?params=' + JSON.stringify({
            sn: sn,
            frm: 'refund',
          }),
        })
      }
      if (orderItems.length == 1) {
        that.refundRequset(orderItems[0].id, that);
      }
    }
  },
  //申请退款
  refundRequset: function (id, that) {
    wx.request({
      url: app.globalData.address + '/api/order/return.html',
      data: {
        orderItemId: id,
        openid: app.globalData.openId,
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.showToast({
            title: '申请退款成功',
            icon: 'success',
            mask: true,
            duration: 1500,
          })
          setTimeout(() => {
            that.setData({
              pageNumber: 1,
              orderAll: [],
              received: []
            }, () => {
              that.orderAll(null)
              that.received(null);
            })

          }, 1000)
        }
      }
    })
  },

  // 订单详情
  toDetailTap: function (e) {
    wx.navigateTo({
      url: "/pages/orderDetail/orderDetail?id=" + e.currentTarget.dataset.id,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // if(app.globalData.exhibitionId!=1){
    //   this.setData({
    //     isExhibition:true
    //   })
    // }
    // else{
    //   this.setData({
    //     isExhibition: false
    //   })
    // }
    var that = this;
    let e = null;
    var currentTab = options.currentTab ? options.currentTab : that.data.currentTab;
    that.setData({
      currentTab: options.currentTab ? options.currentTab : -1,
    });
    if (currentTab == 0) {
      that.setData({
        pageNumber: 1,
        orderAll: [],
      }, () => {
        that.orderAll(e);
      })

    }

    switch (currentTab) {
      case '1':
        that.pendingPayment(e);
        break;
      case '2':
        that.pendingShipment(e);
        break;
      case '3':
        that.shipped(e);
        break;
      case '4':
        that.received(e);
        break;
      default:
        break;
    };
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          clientHeight: res.windowHeight
        });
      }
    });

  },

  //滑动切换
  swiperTab: function (e) {
    var that = this;
    var params = null

    var currentTab = e.detail.current ? e.detail.current : 0;
    that.setData({
      pageNumber: 1,
      orderAll: [],
      order: [],
      pendingPayment: [],
      shipped: [],
      received: [],
      currentTab: e.detail.current,
    }, () => {
      switch (currentTab) {
        case 0:
          that.orderAll(params);
          break;
        case 1:
          that.pendingPayment(params);
          break;
        case 2:
          that.pendingShipment(params);
          break;
        case 3:
          that.shipped(params);
          break;
        case 4:
          that.received(params);
          break;
        default:
          break;
      };
    });

  },

  //点击切换
  clickTab: function (e) {
    if (e === null) {
      return;
    }

    var that = this;

    if (this.data.currentTab === e.currentTarget.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.currentTarget.dataset.current
      })
    }
  },

  // 删除订单
  deleteOrder: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '是否删除该订单',
      success: function (res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.address + '/api/order/delete.html',
            data: {
              openid: app.globalData.openId,
              orderId: e.currentTarget.dataset.sn,
            },
            success: (res) => {
              if (res.data.msg === "success") {
                wx.showToast({
                  title: '订单删除成功',

                })

                that.received(null);
              }

            }
          });
        } else if (res.cancel) {

        }
      }
    });
  },

  //取消订单
  canelOrder: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '是否取消订单',
      success: function (res) {
        if (res.confirm) {

          wx.request({
            url: app.globalData.address + '/api/order/cancel.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {
              if (res.data.msg === "success") {
                wx.showToast({
                  title: '订单取消成功',
                  // complete: this.refresh,
                  // duration: 600,

                })
                that.setData({
                  pageNumber: 1,
                  orderAll: [],
                  pendingPayment: [],
                  order: [],
                }, () => {
                  that.orderAll(null);
                  that.pendingPayment(null);
                  that.pendingShipment(null)
                })


              }
              if (res.data.code === 1) {
                wx.showToast({
                  title: res.data.msg,
                  icon: "none",
                  duration: 1000,
                })
              }
            }
          });
        } else if (res.cancel) {

        }
      }
    })
  },

  // 确认收货
  confirmReceipt: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '是否确认收货',
      success: function (res) {

        if (res.confirm) {
          wx.request({
            url: app.globalData.address + '/api/order/receive.html',
            data: {
              openid: app.globalData.openId,
              sn: e.currentTarget.dataset.sn,
            },
            success: (res) => {


              if (res.data.code == 0) {
                wx.showToast({
                  title: '收货成功',

                  duration: 600,
                })
                that.setData({
                  pageNumber: 1,
                  shipped: [],
                  orderAll: [],
                }, () => {
                  that.shipped(null);
                  that.orderAll(null);
                })


              } else {
                wx.showToast({
                  title: res.data.msg,

                  icon: "none",
                })
              }

            }
          });
        } else if (res.cancel) {

        }
      }
    })
  },

  // 查看物流
  logistics: function (e) {
    wx.navigateTo({
      url: "/pages/logistics-info/logistics-info?orderId=" + e.currentTarget.dataset.sn,
    })
  },

  // 取消支付后跳转到订单页面
  cancelToOrder: function () {
    wx.redirectTo({
      url: '/pages/order/order?currentTab=0'
    })
  },

  // 去支付
  goToPay: function (e) {
    var page = this;
    var sn = e.currentTarget.dataset.sn;
    var index = e.currentTarget.dataset.index;
    var paymethod = '';
    var totalPrice = -1;
    if (e.currentTarget.dataset.sign === 'pendingPayment') {

      totalPrice = page.data.pendingPayment[index].amount;
      paymethod = page.data.pendingPayment[index].payMethod
    }
    if (e.currentTarget.dataset.sign === 'orderAll') {

      totalPrice = page.data.orderAll[index].amount;
      paymethod = page.data.orderAll[index].payMethod
    }
    if (paymethod == '余额支付') {
      console.log(paymethod)
      page.setData({
        paymentPop: true,
        sn: sn,
        totalPrice: totalPrice,
      })
    } else {
      this.setData({
        sn: sn,
        totalPrice: totalPrice,
      }, () => {
        this.payment();
      })
    }
  },

  payment: function () {
    var page = this;
    var sn = page.data.sn;
    var totalPrice = page.data.totalPrice;
    wx.request({
      url: app.globalData.address + '/api/order/create3.html',
      data: {
        openid: app.globalData.openId,
        sn: sn,
        exhibitionId: app.globalData.exhibitionId,
      },
      success: function (res) {
        if (res.data.code === 0) {
          page.setData({
            paymentPop: false,
          })
          page.orderPay(page, res, totalPrice);
        };
        if (res.data.code === 1) {
          wx.showToast({
            title: res.data.msg,
            icon: "none",
            duration: 1000,
          })
        }

      }

    })


  },
  // 支付接口
  orderPay: function (page, res, totalPrice) {
    let data = res.data.data;

    if (data.method === "wx") {
      payment.initPay(data.wx, () => {
        wx.redirectTo({
          url: `/pages/pay-success/pay-success?price=${totalPrice}&&id=${res.data.data.orderId}`
        })
      }, (res) => {
        if (res.errMsg === "requestPayment:fail cancel") {
          wx.showToast({
            title: '支付被取消',
            icon: 'none',
            duration: 650,
          });
          setTimeout(() => {
            page.cancelToOrder();
          }, 650)
        }

      })
    }
    else if (data.method === "balance") {
      if (data.result === "success") {
        wx.showToast({
          title: '余额支付成功',
          icon: "success",
          duration: 1500,
          success: function () {
            setTimeout(() => {
              wx.redirectTo({
                url: `/pages/pay-success/pay-success?price=${totalPrice}&&id=${res.data.data.orderId}`
              })
            }, 1000)
          }
        })
      }
      else {
        wx.showToast({
          title: "余额不足",
          icon: 'none',
          duration: 1500,
        });
      }
    }
  },
  // 获得订单总价


  getOrders: function (e) {
    var currentTab = e.currentTarget.dataset.current;
    var that = this;
    this.setData({
      currentTab: currentTab,
      pageNumber: 1,
      orderAll: [],
      order: [],
      pendingPayment: [],
      shipped: [],
      received: [],
    }, () => {
      switch (currentTab) {
        case '0': that.orderAll(null); break;
        case '1':
          that.pendingPayment(null);
          break;
        case '2':
          that.pendingShipment(null);
          break;
        case '3':
          that.shipped(null);
          break;
        case '4':
          that.received(null);
          break;
        default:
          break;
      };
    })

  },

  // 请求后台数据(全部)
  orderAll: function (e) {
    var that = this;
    that.clickTab(e);
    wx.request({
      url: app.globalData.address + '/api/order/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
        orderType: app.globalData.exhibitionId > 1 ? "exhibition" : "",
        // status:""
      },
      success: function (res) {

        var orderAll = that.data.orderAll;
        if (res.data.code == 0) {
          let order = res.data.data.content;
          for (let i = 0; i < order.length; i++) {
            order[i].status = that.switchStatus(order[i].status)
          }
          if (orderAll.length == 0) {
            orderAll = order;
          }
          else {
            if (that.data.pageNumber <= res.data.data.totalPages) {
              orderAll = orderAll.concat(order);
            }
          }
        }

        that.setData({
          orderAll: orderAll,
        })

      }
    })

  },

  // 请求后台数据(待付款)
  pendingPayment: function (e) {
    var that = this;
    if (e != null) {
      that.clickTab(e);
    }
    wx.request({
      url: app.globalData.address + '/api/order/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
        status: "pendingPayment",
        orderType: app.globalData.exhibitionId > 1 ? "exhibition" : "",
      },
      success: function (res) {

        var pendingPayment = that.data.pendingPayment;
        if (res.data.code == 0) {
          let order = res.data.data.content;
          for (let i = 0; i < order.length; i++) {
            order[i].status = that.switchStatus(order[i].status)
          }
          if (pendingPayment.length == 0) {
            pendingPayment = order;
          }
          else {
            if (that.data.pageNumber <= res.data.data.totalPages) {
              pendingPayment = pendingPayment.concat(order);
            }
          }
        }

        that.setData({
          pendingPayment: pendingPayment,
        })
      }
    })

  },

  // 请求后台数据(待发货)
  pendingShipment: function (e) {
    var that = this;
    if (e != null) {
      that.clickTab(e);
    }
    wx.request({
      url: app.globalData.address + '/api/order/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
        status: "pendingShipment",
        orderType: app.globalData.exhibitionId > 1 ? "exhibition" : "",

      },
      success: function (res) {

        var pendingShipment = that.data.order;
        if (res.data.code == 0) {
          let order = res.data.data.content;
          for (let i = 0; i < order.length; i++) {
            order[i].status = that.switchStatus(order[i].status)
          }
          if (pendingShipment.length == 0) {
            pendingShipment = order;
          }
          else {
            if (that.data.pageNumber <= res.data.data.totalPages) {
              pendingShipment = pendingShipment.concat(order);
            }
          }
        }

        that.setData({
          order: pendingShipment,
        })
      }
    })

  },

  // 请求后台数据(已发货)
  shipped: function (e) {
    var that = this;
    if (e != null) {
      that.clickTab(e);
    }
    wx.request({
      url: app.globalData.address + '/api/order/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
        status: "shipped",
        orderType: app.globalData.exhibitionId > 1 ? "exhibition" : "",
      },
      success: function (res) {

        var shipped = that.data.shipped;
        if (res.data.code == 0) {
          let order = res.data.data.content;
          for (let i = 0; i < order.length; i++) {
            order[i].status = that.switchStatus(order[i].status)
          }
          if (shipped.length == 0) {
            shipped = order;
          }
          else {
            if (that.data.pageNumber <= res.data.data.totalPages) {
              shipped = shipped.concat(order);
            }
          }
        }

        that.setData({
          shipped: shipped,
        })

      }
    })
  },

  // 请求后台数据[待评价(已收货)]
  received: function (e) {
    var that = this;
    if (e != null) {
      that.clickTab(e);
    }
    wx.request({
      url: app.globalData.address + '/api/order/list.html',
      data: {
        openid: app.globalData.openId,
        pageNumber: that.data.pageNumber,
        pageSize: that.data.pageSize,
        status: "received",
        orderType: app.globalData.exhibitionId > 1 ? "exhibition" : "",
      },
      success: function (res) {
        var received = that.data.received;
        if (res.data.code == 0) {
          console.log(1);
          let order = res.data.data.content;
          for (let i = 0; i < order.length; i++) {
            order[i].status = that.switchStatus(order[i].status)
          }
          if (received.length == 0) {
            received = order;
          }
          else {
            if (that.data.pageNumber <= res.data.data.totalPages) {
              received = received.concat(order);
            }
          }
        }

        that.setData({
          received: received,
        })
      }
    })
  },

  switchStatus: function (status) {
    let StatusStr = '';
    if (status === 'pendingPayment') {
      StatusStr = '待付款';
    } else if (status === 'pendingShipment') {
      StatusStr = '待发货'
    } else if (status === 'shipped') {
      StatusStr = '已发货'
    } else if (status === 'received') {
      StatusStr = '已收货'
    } else if (status === 'canceled') {
      StatusStr = '已取消'
    } else if (status === 'pendingReview') {
      StatusStr = '待审核'
    } else if (status === 'completed') {
      StatusStr = '已完成'
    } else if (status === 'failed') {
      StatusStr = '已失败'
    } else if (status === 'denied') {
      StatusStr = '已拒绝'
    }
    return StatusStr;

  },

  // 取消支付
  payError: function () {
    this.setData({
      paymentPop: false,
    }, () => {
      wx.showToast({
        title: '支付取消',
        icon: 'none',
        duration: 1000,
      })
    })
  },
  noticelongtap: function () {
    return
  },

  // 分页刷新订单
  refreshOrder: function () {
    console.log(1);
    var currentTab = '' + this.data.currentTab;
    var e = null;
    var that = this;
    this.setData({
      pageNumber: that.data.pageNumber + 1,
    }, () => {
      switch (currentTab) {
        case '0': that.orderAll(e); break;
        case '1':
          that.pendingPayment(e);
          break;
        case '2':
          that.pendingShipment(e);
          break;
        case '3':
          that.shipped(e);
          break;
        case '4':
          that.received(e);
          break;
        default:
          break;
      };
    })
  }
})