// pages/distribution/distribution.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    distribution:[],
    
   
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    this.distributionTap()
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

 

  
  // 提现跳转
  tixianTap:function(e){
    
    wx.navigateTo({
      url: '/pages/withdrawCash/withdrawCash?canUseAmount=' + e.currentTarget.dataset.canuseamount,
    })
    // wx.setStorageSync('canUseAmount', e.currentTarget.dataset.canUseAmount)
  },
// 分销订单跳转
  orderTap:function(){
    wx.navigateTo({
      url: '/pages/distribution-order/distribution-order?currentTab=0',
    })
  },
  // 分销佣金的跳转
  goToDistribution:function(){
    wx.navigateTo({
      url: '/pages/distribution/distribution',
    })
  },
  
  goToMyteam:function(){
    wx.navigateTo({
      url: '/pages/myTeam/myTeam',
    })
  },

  // 请求后台
  distributionTap:function(){
    var that=this
    wx.request({
      url: app.globalData.address + "/api/distributionBrokerage/center.html",
      data:{
        openid: app.globalData.openId,
      },
      success:function(res){
        that.setData({
          distribution:res.data.data
        })
      }
    })
  },

  // 二维码跳转
  goToQRcode:function(){
    wx.navigateTo({
      url: '/pages/QR-code/QR-code',
    })
  },

  // 提现明细跳转
  detailTap:function(){
    wx.navigateTo({
      url: '/pages/distribution-detail/distribution-detail?currentTab=0',
    })
  }
})