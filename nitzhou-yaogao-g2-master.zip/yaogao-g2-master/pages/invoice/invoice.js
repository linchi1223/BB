const phoneRegex = /^1\d{10}$/;
const emaileRegex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
const app = getApp();
Page({
  data:{
    person:true,
    company:false,
    money:0,
    personCode:'',
    personName:'',
    companyName:'',
    cardNumber:'',
    bankName:'',
    invoiceTitle:'person',
    invoiceContent:'明细',
    invoiceStyle: ['纸质增值税普通发票', '纸质增值税专用发票'],
    index:0,
  },

  onLoad:function(options){
    var param = JSON.parse(options.params);
    this.setData({
      personName:param.name,
      phone:param.phone,
      money:param.money,
    })
    this.getInvoice('person');
  },



  selectPerson:function(e){
    var person = this.data.person;
    if(person)
    {
      return;
    }
    else{
      this.setData({
        person:!person,
        company:false,
        invoiceTitle: e.currentTarget.dataset.title,
      },()=>{
        this.getInvoice(e.currentTarget.dataset.title)
      })
    }
  },

  selectCompany:function(e){
    var company = this.data.company;
    if(company){
      return
    }
    else{
      this.setData({
        company: !company,
        person:false,
        invoiceTitle: e.currentTarget.dataset.title,
      },()=>{
        this.getInvoice(e.currentTarget.dataset.title)
      })
    }

  },

  getInvoiceStyle:function(e){
    var index = e.detail.value;
    var company = this.data.company;
    if(index==0)
    {
      this.setData({
      index: index,
      })
    }
    else if(index == 1 ){
      this.setData({
        index: index,
        company: true,
        person: false,
        invoiceTitle: 'company',
      },()=>{
        this.getInvoice('company');
      })
    }
    
  },

  getPersonName:function(e){
    var personName = e.detail.value;
    this.setData({
      personName:personName,
    })
  },

  getPersonCode:function(e){
    var personcode = e.detail.value;
    this.setData({
      personCode:personcode,
    })
  },

  getCompanyName:function(e){
    var companyName = e.detail.value;
    this.setData({
      companyName:companyName,
    })
  },

  getBankName:function(e){
    var bankName = e.detail.value;
    this.setData({
      bankName: bankName,
    })
  },

  getCardNumber:function(e){
    var cardNumber = e.detail.value;
    this.setData({
      cardNumber: cardNumber,
    })
  },

  // getPersonTele:function(e){
  //   var phone = e.detail.value;
  //   if(phoneRegex.test(phone))
  //   {
  //     this.setData({
  //       phone : phone,
  //     })
  //   }
  //   else{
  //     wx.showToast({
  //       title: '请输入正确的手机号码',
  //       icon:'none',
  //       mask:true,
  //       duration:1200,
  //     })
  //   }
  // },

  // getEmail:function(e){
  //   var Email = e.detail.value;
  //   if(emaileRegex.test(Email))
  //   {
  //     this.setData({
  //       Email:Email,
  //     })
  //   }
  //   else{
  //     wx.showToast({
  //       title: '请输入正确的邮箱号',
  //       icon:'none',
  //       mask:true,
  //       duration:1200,
  //     })
  //   }
  // },

// 保存事件
  setInvoice:function(){
    var that =this;
    var index = this.data.index;
    if(that.data.person)
    {
      if (!that.data.personName) //||!phoneRegex.test(phone)
      {
        wx.showToast({
          title: '请输入完整内容',
          icon:'none',
          mask:true,
          duration:1200,
        })
        return;
      }
      var data={
        title:that.data.personName,
        itype : that.data.invoiceStyle[that.data.index],
        genre:that.data.invoiceTitle,
        code:null,
        openid:app.globalData.openId,
      }

    }
    if(that.data.company){
      var companyName = that.data.companyName;
      var personCode = that.data.personCode;
      var cardNumber = that.data.cardNumber;
      var bankName = that.data.bankName;
      if(index==1)
      {
        if (!companyName || !personCode || !cardNumber || !bankName) //||!phoneRegex.test(phone)
        {
          wx.showToast({
            title: '请输入完整内容',
            icon: 'none',
            mask: true,
            duration: 1200,
          })
          return;
        }
      }
      else{
        if (!companyName || !personCode) //||!phoneRegex.test(phone)
        {
          wx.showToast({
            title: '请输入完整内容',
            icon: 'none',
            mask: true,
            duration: 1200,
          })
          return;
        }
      }
      var data={
        title: that.data.companyName,
        itype: that.data.invoiceStyle[that.data.index],
        genre: that.data.invoiceTitle,
        code: that.data.personCode,
        card:that.data.cardNumber,
        bankName: that.data.bankName,
        openid: app.globalData.openId,
      }
    }
    that.InvoiceRequset(data);
  },

  // 保存发票接口
  InvoiceRequset:function(data){
    wx.request({
      url: app.globalData.address +'/api/order/invoice.html',
      data:data,
      success:function(res){
        var id=res.data.data;
        const pages = getCurrentPages();
        const beforepage = pages[pages.length-2];
        if (beforepage.__route__ === 'pages/order-submit/order-submit')
        {
          beforepage.setData({
            invoiceId: id,
            invoiceText: true,
          },()=>{
            beforepage.getOrderData(beforepage.data.options)
            wx.navigateBack();
          })
        }
      }
    })
  },

  getInvoice:function(genre){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/order/getinvoice.html',
      data:{
        openid: app.globalData.openId,
        genre: genre,
        itype: that.data.invoiceStyle[that.data.index],
      },
      success:function(res){
        let invoice ;
        if(res.data.code == 0)
        {
          invoice = res.data.data;
          that.setData({
            invoice:invoice,
            personCode: invoice.code,
            personName: invoice.title,
            companyName: invoice.title,
            cardNumber: invoice.card,
            bankName: invoice.bankName,
          })
        }
      }

    })
  }


})