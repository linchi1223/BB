var interval = null;
const app = getApp();
Page({
  data:{
    sales:100,
    startFlag:0,
    timeLine:[],
    goods:[],
    status:3,
    width:30,
    currentIndex:0,
    hours: 0,
    seconds: 0,
    minutes: 0,
    totolSecond: 0,
    image:'',
  
  },
  onLoad:function(options){
    this.getTimeLineReq();
    this.getBackgroundReq();
  },
  onShow:function(){

  },
  onReachBottom:function(){

  },
  onHide: function(){
    clearInterval(interval);
  },

  timeBindTap:function(e){
    var that = this;
    var status = 3;
    var timeLine = this.data.timeLine;
    var index = e.currentTarget.dataset.index;
    for (var i = 0; i < timeLine.length;i++){
      if(timeLine[i].select){
        timeLine[i].select = false;
      }
    }
    if(timeLine[index].status=='已开抢')
    {
      status = 2;
    }
    else if(timeLine[index].status=='抢购中')
    {
      status = 3;
    }
    else if (timeLine[index].status == '即将开抢')
    {
      status = 1;
    }
    else{
      console.log("error")
    }
    timeLine[index].select = true;
    
    this.setData({
      timeLine:timeLine,
      currentIndex:index,
      status: status,
    },()=>{
      that.getTimeGoodsLsitReq(timeLine[index].startTime,timeLine[index].endTime);
    })
  },

  setCountDown: function () {
    const that = this;
    var timeLine = that.data.timeLine;
    var backData;
    var hour;
    var time;
    var str;
    var totolSeconds;
    var minutes;
    var seconds;
    var nowDate;
    var index;

    nowDate = new Date();
    backData = that.getBorder(timeLine, nowDate);
    console.log(backData);
    str = backData.str

    index = backData.index >= 0 ? backData.index : 0;

    time = new Date(str);
    totolSeconds = Math.floor((time - nowDate) / 1000);
    if (totolSeconds == 0) {
      // 请求后台数据；
      that.getTimeGoodsLsitReq(timeLine[index].startTime, timeLine[index].endTime);
    }
    hour = parseInt((totolSeconds / 60 / 60));
    minutes = parseInt((totolSeconds - (hour * 60 * 60)) / 60);

    seconds = parseInt((totolSeconds - (hour * 60 * 60) - (minutes * 60)));
    for(var i=0;i<timeLine.length;i++)
    {
      timeLine[i].ongoing = false;
      timeLine[i].select = false;
    }
      timeLine[index].ongoing = true;
      timeLine[index].select = true;
    
    that.setData({
      hours: hour < 10 ? ('0' + hour) : hour,
      minutes: minutes < 10 ? ('0' + minutes) : minutes,
      seconds: seconds < 10 ? ('0' + seconds) : seconds,
      timeLine: timeLine,
    },()=>{
   
      that.getTimeGoodsLsitReq(timeLine[index].startTime, timeLine[index].endTime);
    })
    
    that.setIntervalReq(that,timeLine);

  },

  // 循环获得后台数据
  setIntervalReq:function(that,timeLine){
    var timeArray = timeLine;
    var backData;
    var hour;
    var time;
    var str;
    var totolSeconds;
    var minutes;
    var seconds;
    var nowDate;
    var temp;
    var index;
    interval = setInterval(function () {
      nowDate = new Date();
      backData = that.getBorder(timeLine, nowDate);

      index = backData.index>= 0? backData.index: 0;

      str = backData.str
      time = new Date(str);
      totolSeconds = Math.floor((time - nowDate) / 1000);
      if (totolSeconds == 0) {
        // 请求后台数据；
        that.getTimeLineReq();
        for (var i = 0; i < timeArray.length; i++) {
          timeArray[i].ongoing = false;
          timeArray[i].select = false;
        }
        timeArray[index].ongoing = true;
        timeArray[index].select = true;
        that.getTimeGoodsLsitReq(timeArray[index].startTime,timeArray[index].endTime);
      }

      hour = parseInt((totolSeconds / 60 / 60));
      minutes = parseInt((totolSeconds - (hour * 60 * 60)) / 60);

      seconds = parseInt((totolSeconds - (hour * 60 * 60) - (minutes * 60)));

      
      that.setData({
        hours: hour < 10 ? ('0' + hour) : hour,
        minutes: minutes < 10 ? ('0' + minutes) : minutes,
        seconds: seconds < 10 ? ('0' + seconds) : seconds,
        timeLine: timeArray,
      })
    }, 1000)
  },
  //根据时间获得商品列表
  getTimeGoodsLsitReq: function (startTime, endTime){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/goods/timeLimitList.html',
      data:{
        startTime: startTime,
        endTime: endTime,
      },
      success:function(res)
      {
        console.log(res);
        that.setData({
          goods: res.data.content,
        })
      }
    })
  },

  // 获得区间
  getBorder: function (timeLine, nowDate) {
    var that = this;
    var now = new Date(nowDate);

    var time;
    var totolSeconds;
    var rebackDate={};
    var str;
    for (var i = 0; i < timeLine.length; i++) {
      
      str = timeLine[i].endTime;
      time = new Date(str);
      totolSeconds = time - now;
      if (totolSeconds >= 0) {
        // console.log('1')
        rebackDate.str=str;
        rebackDate.index = i;
        return rebackDate;
        // break;
      }
    }
  },


 // 得到时间轴
  getTimeLineReq:function(){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/limit/list.html',
      data:{

      },
      success:function(res){
        var timeLine = res.data;
        var i,day,time,temp;
        var nowDate = new Date();
        var today = that.fillnumber(nowDate.getFullYear()) + '/' + that.fillnumber(nowDate.getMonth()+1) + '/' + that.fillnumber(nowDate.getDate());
        for(i in timeLine){
          
          timeLine[i].startTime = that.dateToString(timeLine[i].startTime);
          day = timeLine[i].startTime.split(' ')[0];
          temp = timeLine[i].startTime.split(' ')[1].split(':') ;
          time = temp[0]+':'+temp[1];

          timeLine[i].endTime = that.dateToString(timeLine[i].endTime);
          if(that.CompareDate(day,today)==0)
          {
            timeLine[i].showTime = time
          }
          else if (that.CompareDate(day, today) > 0)
          {
            timeLine[i].showTime = "明日" + time
          }
          else if (that.CompareDate(day, today) < 0)
          {
            timeLine[i].showTime = timeLine[i].startTime.split(' ')[0].split('/')[2] + "日" + time
          }
          timeLine[i].select = false;
          timeLine[i].ongoing = false;
        }
        that.setData({
          timeLine: timeLine,
        },()=>{
          if (that.data.startFlag==0)
          {
            that.setCountDown();
          }
          that.setData({
            startFlag: 1,
          })
          
        })
      }
    })
  },


  fillnumber:function(num){
    var str;
    if(num<10)
    {
      str = '0'+num;
    }
    else{
      str = String(num);
    }
    return str;
  },


  // 时间戳转化成日期字符串
    dateToString:function(time_stamp){
      var that = this;
      var str;
      var i;
      var year, day, month, time;
      var date;
      date = new Date(time_stamp);
      year = date.getFullYear()
      month = that.fillnumber(date.getMonth() + 1);
      day = that.fillnumber(date.getDate());
      time = that.fillnumber(date.getHours()) + ':' + that.fillnumber(date.getMinutes()) + ':' + that.fillnumber(date.getSeconds());
      str = year + '/' + month + '/' + day + ' ' + time;

      return str;
    },


 // 日期之间比较大小
  CompareDate: function (param1, param2)
  {
    var param1Date = new Date(param1);
    var param2Date = new Date(param2);
    var differ = param1Date - param2Date
    if(differ==0)
    {
      return 0;
    }
    else if(differ>0)
    {
      return 1;
    }
    else if(differ<0)
    {
      return -1;
    }
    else{
      console.log("error");
    }
  },

  //商品区跳转
  toDetailsTap: function (e) {
    wx.navigateTo({
      url: "/pages/goods-new/goods-new?id=" + e.currentTarget.dataset.id
    })
  },

  getBackgroundReq:function(){
    var that = this;
    wx.request({
      url: app.globalData.address +'/api/article/background2.html',
      data:{},
      success:function(res){

        if(res.data.code==0)
        {
          that.setData({
            image:res.data.data.image,
          })
        }
      }
    })
  }
 


})